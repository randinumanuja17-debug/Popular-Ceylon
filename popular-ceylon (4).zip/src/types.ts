export type ScreenType = 'expeditions' | 'destinations' | 'estates' | 'bespoke' | 'journal';

export interface ItineraryDay {
  day: number;
  title: string;
  region: string;
  elevationMeters: number;
  terrainType: 'highland' | 'cultural' | 'wildlife' | 'coastal';
  hasTrainCrossing?: boolean;
  trainDetails?: string;
  lodgingName: string;
  lodgingType: string;
  lodgingImage: string;
  summary: string;
  highlights: string[];
  travelPace: 'Gentle' | 'Immersive' | 'Active';
}

export interface Expedition {
  id: string;
  title: string;
  subtitle: string;
  tagline: string;
  durationDays: number;
  season: string;
  startingPriceUsd: number;
  startingPriceGbp: number;
  heroImage: string;
  galleryImages: string[];
  routeSummary: string;
  elevationRange: string;
  travelStyle: string;
  maxGuests: number;
  overview: string;
  includedPrivileges: string[];
  days: ItineraryDay[];
}

export interface Destination {
  id: string;
  name: string;
  sinhalaName: string;
  region: 'Central Highlands' | 'Cultural Triangle' | 'Deep South & Coast' | 'Eastern Wilderness' | 'Western Galle Coast';
  elevation: string;
  climate: string;
  bestMonths: string;
  heroImage: string;
  summary: string;
  editorialInsight: string;
  highlights: string[];
  coordinates: { x: number; y: number }; // percentage on island map
}

export interface HeritageEstate {
  id: string;
  name: string;
  location: string;
  category: 'Colonial Tea Planter' | 'Tropical Modernism' | 'Private Safari Lodge' | 'Coastal Beachfront';
  builtYear: string;
  architectOrFounder: string;
  startingNightlyUsd: number;
  heroImage: string;
  description: string;
  signatureExperience: string;
  amenities: string[];
  elevation: string;
}

export interface JournalArticle {
  id: string;
  title: string;
  category: 'Architecture' | 'Botany & Tea' | 'Wildlife Chronicles' | 'Ancient Heritage';
  author: string;
  authorTitle: string;
  readTime: string;
  publishDate: string;
  heroImage: string;
  excerpt: string;
  pullQuote: string;
  content: string[];
}

export interface BespokePlanPreferences {
  duration: number;
  season: 'Winter Sun (Dec-Apr)' | 'Summer Hill Breeze (May-Aug)' | 'Autumn Solitude (Sep-Nov)';
  style: 'Heritage & Tea' | 'Wild Big Game Safari' | 'Sacred Relics & Ruins' | 'Coastal Sanctuary';
  regions: string[];
  lodgingTier: 'Signature Heritage' | 'Private Ultra-Luxe Pavilions' | 'Royal Colonial Suites';
  transportMode: 'Executive Chauffeur SUV' | 'Scenic Train + Chauffeur' | 'Helicopter & Floatplane Transfers';
  privileges: string[];
  guests: number;
}
