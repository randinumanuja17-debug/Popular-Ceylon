import React from 'react';
import { ScreenType } from '../types';

interface FooterProps {
  onSelectScreen: (screen: ScreenType) => void;
  onOpenBooking: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onSelectScreen,
  onOpenBooking,
}) => {
  return (
    <footer className="bg-[#0F382A] text-[#FDFBF7] border-t border-[#D4AF37]/30 pt-16 pb-12 mt-20">
      <div className="max-w-[1440px] mx-auto px-6 md:px-12 lg:px-16">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-14 border-b border-[#D4AF37]/20">
          {/* Brand & Provenance */}
          <div className="md:col-span-5 space-y-4">
            <span className="font-serif text-3xl font-semibold tracking-tight text-[#FDFBF7] block">
              Popular Ceylon
            </span>
            <p className="text-sm text-[#FDFBF7]/80 leading-relaxed max-w-sm">
              Architects of bespoke high-altitude tea journeys, colonial estate residencies,
              and private big-game wildlife expeditions across Sri Lanka.
            </p>
            <div className="pt-2 text-xs text-[#D4AF37] tracking-wider uppercase font-semibold">
              Heritage Ceylon · Colombo · Hatton · Galle Fort
            </div>
          </div>

          {/* Nav Collections */}
          <div className="md:col-span-2 space-y-3">
            <h4 className="text-xs uppercase tracking-[0.14em] font-semibold text-[#D4AF37]">
              Expeditions
            </h4>
            <ul className="space-y-2 text-sm text-[#FDFBF7]/75">
              <li>
                <button
                  onClick={() => onSelectScreen('expeditions')}
                  className="hover:text-[#FDFBF7] transition-colors cursor-pointer text-left"
                >
                  Highland Tea Passage
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectScreen('expeditions')}
                  className="hover:text-[#FDFBF7] transition-colors cursor-pointer text-left"
                >
                  Royal Kingdoms & Yala
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectScreen('expeditions')}
                  className="hover:text-[#FDFBF7] transition-colors cursor-pointer text-left"
                >
                  Southern Cinnamon Coast
                </button>
              </li>
            </ul>
          </div>

          {/* Sanctuaries & Cartography */}
          <div className="md:col-span-2 space-y-3">
            <h4 className="text-xs uppercase tracking-[0.14em] font-semibold text-[#D4AF37]">
              Exploration
            </h4>
            <ul className="space-y-2 text-sm text-[#FDFBF7]/75">
              <li>
                <button
                  onClick={() => onSelectScreen('destinations')}
                  className="hover:text-[#FDFBF7] transition-colors cursor-pointer text-left"
                >
                  Island Cartography
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectScreen('estates')}
                  className="hover:text-[#FDFBF7] transition-colors cursor-pointer text-left"
                >
                  Planter Bungalows
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectScreen('journal')}
                  className="hover:text-[#FDFBF7] transition-colors cursor-pointer text-left"
                >
                  Ceylon Journal
                </button>
              </li>
            </ul>
          </div>

          {/* Private Inquiries */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs uppercase tracking-[0.14em] font-semibold text-[#D4AF37]">
              Curator Desk
            </h4>
            <p className="text-xs text-[#FDFBF7]/75 leading-relaxed">
              Inquiries regarding private air charters, vintage rail carriages, and buyout of heritage tea bungalows.
            </p>
            <button
              onClick={onOpenBooking}
              className="mt-2 px-5 py-2.5 rounded-lg bg-[#D4AF37] text-[#0F382A] text-xs font-semibold hover:bg-[#F4E298] transition-colors cursor-pointer"
            >
              Curate Private Journey
            </button>
          </div>
        </div>

        {/* Quiet Copyright & Conservation Commitment */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#FDFBF7]/60">
          <div>
            © {new Date().getFullYear()} Popular Ceylon Travel Group. All rights reserved.
          </div>
          <div className="flex items-center gap-4 text-xs text-[#D4AF37]/90">
            <span>Committed to 100% Ethical Wildlife & Highland Reforestation</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
