import React from 'react';
import { ItineraryDay } from '../types';
import { Mountain, Waves, Train, Compass, Trees } from 'lucide-react';

interface ItineraryMilestoneBarProps {
  days: ItineraryDay[];
  activeDay: number;
  onSelectDay: (day: number) => void;
}

export const ItineraryMilestoneBar: React.FC<ItineraryMilestoneBarProps> = ({
  days,
  activeDay,
  onSelectDay,
}) => {
  return (
    <div className="w-full bg-[#F8F5EE] border border-[#D4AF37]/30 rounded-xl p-5 md:p-6 shadow-ceylon">
      {/* Header with signature kicker and current elevation status */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6 pb-4 border-b border-[#D4AF37]/20">
        <div>
          <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-[#D4AF37] block">
            Signature Expedition Trajectory
          </span>
          <h4 className="font-serif text-lg font-semibold text-[#0F382A]">
            Day-by-Day Milestone & Elevation Profile
          </h4>
        </div>

        <div className="flex items-center gap-4 text-xs text-[#414844]">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#10B981]" />
            Active Waypoint
          </span>
          <span className="flex items-center gap-1.5">
            <Train className="w-3.5 h-3.5 text-[#D4AF37]" />
            Rail Passage
          </span>
          <span className="flex items-center gap-1.5">
            <Mountain className="w-3.5 h-3.5 text-[#0F382A]" />
            Highland Peak
          </span>
        </div>
      </div>

      {/* Horizontal Step Bar with Hairline Golden Thread */}
      <div className="relative overflow-x-auto pb-4 pt-2 -mx-2 px-2 scrollbar-thin">
        {/* Hairline Golden Thread Line */}
        <div 
          className="absolute top-9 left-8 right-8 h-[2px] bg-[#D4AF37]/40 z-0 hidden md:block" 
          aria-hidden="true"
        />

        <div className="flex items-start justify-between min-w-[700px] md:min-w-0 relative z-10 gap-3 md:gap-2">
          {days.map((d) => {
            const isSelected = activeDay === d.day;
            const isTrain = d.hasTrainCrossing;

            return (
              <button
                key={d.day}
                onClick={() => onSelectDay(d.day)}
                className={`flex-1 flex flex-col items-center group cursor-pointer text-center transition-all duration-200 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#0F382A] rounded-lg p-1.5 ${
                  isSelected
                    ? 'scale-105'
                    : 'opacity-85 hover:opacity-100 hover:translate-y-[-2px]'
                }`}
              >
                {/* Day Marker Circle with Serif Numeral */}
                <div
                  className={`w-12 h-12 rounded-full flex flex-col items-center justify-center transition-all duration-200 border-2 ${
                    isSelected
                      ? 'bg-[#0F382A] text-[#FDFBF7] border-[#D4AF37] shadow-lg shadow-[#0F382A]/20'
                      : 'bg-[#FDFBF7] text-[#0F382A] border-[#D4AF37]/50 group-hover:border-[#0F382A]'
                  }`}
                >
                  <span className="text-[9px] uppercase tracking-wider font-semibold opacity-70">
                    Day
                  </span>
                  <span className="font-serif text-sm font-semibold leading-none">
                    {d.day < 10 ? `0${d.day}` : d.day}
                  </span>
                </div>

                {/* Region & Elevation Pill Indicator */}
                <div className="mt-2.5 flex flex-col items-center gap-1 w-full px-1">
                  <span
                    className={`text-xs font-semibold truncate max-w-[110px] ${
                      isSelected ? 'text-[#0F382A]' : 'text-[#414844]'
                    }`}
                  >
                    {d.region.split('·')[0].split('&')[0]}
                  </span>

                  {/* Elevation & Terrain Glyph */}
                  <div className="flex items-center gap-1 text-[11px] font-mono tabular-nums text-[#717974]">
                    {d.terrainType === 'highland' && (
                      <Mountain className="w-3 h-3 text-[#0F382A]" />
                    )}
                    {d.terrainType === 'coastal' && (
                      <Waves className="w-3 h-3 text-[#10B981]" />
                    )}
                    {d.terrainType === 'cultural' && (
                      <Compass className="w-3 h-3 text-[#D4AF37]" />
                    )}
                    {d.terrainType === 'wildlife' && (
                      <Trees className="w-3 h-3 text-[#10B981]" />
                    )}
                    <span>{d.elevationMeters}m</span>
                  </div>

                  {/* Train crossing badge if applicable */}
                  {isTrain && (
                    <span className="inline-flex items-center gap-1 text-[10px] font-medium text-[#735c00] bg-[#fed65b]/30 px-1.5 py-0.5 rounded border border-[#D4AF37]/40">
                      <Train className="w-2.5 h-2.5" />
                      Rail
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
