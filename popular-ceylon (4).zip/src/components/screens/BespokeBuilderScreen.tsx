import React, { useState } from 'react';
import { BespokePlanPreferences } from '../../types';
import { Sparkles, Calendar, Clock, Check, Plane, Compass, ShieldCheck, ArrowRight, DollarSign } from 'lucide-react';

interface BespokeBuilderScreenProps {
  onOpenBookingWithCustomPlan: (customSummary: string) => void;
  initialDestinationName?: string;
}

export const BespokeBuilderScreen: React.FC<BespokeBuilderScreenProps> = ({
  onOpenBookingWithCustomPlan,
  initialDestinationName,
}) => {
  const [duration, setDuration] = useState<number>(10);
  const [season, setSeason] = useState<string>('Winter Sun (Dec-Apr)');
  const [style, setStyle] = useState<string>('Heritage & Tea');
  const [selectedRegions, setSelectedRegions] = useState<string[]>([
    'Central Highlands & Bogawantalawa',
    'Galle Fort & Cinnamon Coast',
    initialDestinationName || 'Sigiriya & Cultural Triangle',
  ]);
  const [tier, setTier] = useState<string>('Signature Heritage Planters');
  const [transport, setTransport] = useState<string>('Scenic Vintage Rail + Executive SUV');
  const [guests, setGuests] = useState<number>(2);

  const [privilegeHeli, setPrivilegeHeli] = useState<boolean>(true);
  const [privilegeTeaMaster, setPrivilegeTeaMaster] = useState<boolean>(true);
  const [privilegeNaturalist, setPrivilegeNaturalist] = useState<boolean>(true);
  const [privilegeWhaleYacht, setPrivilegeWhaleYacht] = useState<boolean>(false);

  const allRegions = [
    'Central Highlands & Bogawantalawa',
    'Sigiriya & Cultural Triangle',
    'Galle Fort & Cinnamon Coast',
    'Yala & Deep Southern Wilderness',
    'Sacred Kandy & Knuckles Range',
    'Tangalle & Blue Bay Sanctuaries',
  ];

  const toggleRegion = (region: string) => {
    if (selectedRegions.includes(region)) {
      if (selectedRegions.length > 1) {
        setSelectedRegions(selectedRegions.filter((r) => r !== region));
      }
    } else {
      setSelectedRegions([...selectedRegions, region]);
    }
  };

  // Live estimate calculation
  const baseDayRate = tier.includes('Royal') ? 1200 : tier.includes('Villas') ? 950 : 750;
  const transportRate = transport.includes('Helicopter') ? 3500 : transport.includes('Rail') ? 900 : 500;
  const privilegesCost =
    (privilegeHeli ? 2400 : 0) +
    (privilegeTeaMaster ? 450 : 0) +
    (privilegeNaturalist ? 650 : 0) +
    (privilegeWhaleYacht ? 1200 : 0);

  const totalInvestmentUsd = duration * baseDayRate * Math.max(1, guests * 0.85) + transportRate + privilegesCost;
  const perGuestUsd = Math.round(totalInvestmentUsd / guests);

  const bespokeSummary = `${duration}-Day Bespoke Ceylon Journey (${style}, ${selectedRegions.length} regions, ${guests} guests)`;

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-[#1A202C]">
      {/* Editorial Header */}
      <section className="pt-12 pb-14 md:pt-16 md:pb-20 border-b border-[#D4AF37]/20">
        <div className="max-w-[1440px] mx-auto px-6 md:px-12 lg:px-16">
          <div className="max-w-3xl">
            <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[#D4AF37] block mb-3">
              Private Atelier
            </span>
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-medium tracking-tight text-[#0F382A] leading-tight mb-6">
              Bespoke Journey Architect
            </h1>
            <p className="text-base sm:text-lg text-[#414844] leading-relaxed">
              Design a tailored expedition shaped around your personal tempo, preferred
              colonial bungalows, and private privileges across the island.
            </p>
          </div>
        </div>
      </section>

      {/* Main Interactive Customizer Layout */}
      <section className="py-12 md:py-16">
        <div className="max-w-[1440px] mx-auto px-6 md:px-12 lg:px-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            {/* Customizer Controls Column */}
            <div className="lg:col-span-8 space-y-10">
              {/* Step 1: Duration & Season */}
              <div className="bg-[#F8F5EE] border border-[#D4AF37]/30 rounded-2xl p-6 sm:p-8 shadow-ceylon">
                <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-[#D4AF37] block mb-2">
                  01. Duration & Timing
                </span>
                <h3 className="font-serif text-2xl font-semibold text-[#0F382A] mb-4">
                  Expedition Length & Season
                </h3>

                <div className="space-y-5">
                  <div>
                    <label className="block text-xs font-semibold text-[#1A202C] mb-2 uppercase tracking-wider">
                      Journey Duration: <span className="text-[#0F382A] font-mono">{duration} Days</span>
                    </label>
                    <div className="grid grid-cols-4 gap-2 sm:gap-3">
                      {[7, 10, 14, 21].map((d) => (
                        <button
                          key={d}
                          type="button"
                          onClick={() => setDuration(d)}
                          className={`py-3 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer border ${
                            duration === d
                              ? 'bg-[#0F382A] text-[#FDFBF7] border-[#0F382A]'
                              : 'bg-[#FDFBF7] text-[#414844] border-[#D4AF37]/30 hover:border-[#D4AF37]'
                          }`}
                        >
                          {d} Days
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-[#1A202C] mb-1.5 uppercase tracking-wider">
                        Travel Season
                      </label>
                      <select
                        value={season}
                        onChange={(e) => setSeason(e.target.value)}
                        className="w-full bg-[#FDFBF7] border border-[#1A202C]/15 rounded-lg py-2.5 px-3 text-sm text-[#1A202C] focus:border-[#0F382A] focus:outline-none focus:ring-1 focus:ring-[#D4AF37]"
                      >
                        <option value="Winter Sun (Dec-Apr)">Winter Sun (Dec - Apr: Peak Season)</option>
                        <option value="Summer Hill Breeze (May-Aug)">Summer Hill Breeze (May - Aug)</option>
                        <option value="Autumn Solitude (Sep-Nov)">Autumn Solitude (Sep - Nov: Serene)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-[#1A202C] mb-1.5 uppercase tracking-wider">
                        Traveling Party
                      </label>
                      <div className="flex items-center gap-3 bg-[#FDFBF7] border border-[#1A202C]/15 rounded-lg py-1 px-3">
                        <button
                          type="button"
                          onClick={() => setGuests(Math.max(1, guests - 1))}
                          className="w-8 h-8 rounded bg-[#F8F5EE] border border-[#D4AF37]/30 text-[#0F382A] font-bold text-sm hover:bg-[#0F382A] hover:text-[#FDFBF7] transition-colors cursor-pointer"
                        >
                          -
                        </button>
                        <span className="flex-1 text-center font-mono font-semibold text-sm">
                          {guests} {guests === 1 ? 'Guest' : 'Guests'}
                        </span>
                        <button
                          type="button"
                          onClick={() => setGuests(Math.min(8, guests + 1))}
                          className="w-8 h-8 rounded bg-[#F8F5EE] border border-[#D4AF37]/30 text-[#0F382A] font-bold text-sm hover:bg-[#0F382A] hover:text-[#FDFBF7] transition-colors cursor-pointer"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Step 2: Desired Regions */}
              <div className="bg-[#F8F5EE] border border-[#D4AF37]/30 rounded-2xl p-6 sm:p-8 shadow-ceylon">
                <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-[#D4AF37] block mb-2">
                  02. Geographic Trajectory
                </span>
                <h3 className="font-serif text-2xl font-semibold text-[#0F382A] mb-2">
                  Select Regions Along Your Route
                </h3>
                <p className="text-xs text-[#717974] mb-4">
                  Select up to 4 regions for seamless logistical rhythm and low travel friction.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {allRegions.map((region) => {
                    const isSelected = selectedRegions.includes(region);
                    return (
                      <div
                        key={region}
                        onClick={() => toggleRegion(region)}
                        className={`p-3.5 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                          isSelected
                            ? 'bg-[#FAF7F0] border-[#0F382A] ring-1 ring-[#D4AF37]/50'
                            : 'bg-[#FDFBF7] border-[#D4AF37]/20 hover:border-[#D4AF37]/60'
                        }`}
                      >
                        <span className="text-xs font-semibold text-[#0F382A]">
                          {region}
                        </span>
                        <div
                          className={`w-5 h-5 rounded flex items-center justify-center border transition-colors ${
                            isSelected
                              ? 'bg-[#0F382A] border-[#D4AF37]'
                              : 'bg-[#FDFBF7] border-[#717974]'
                          }`}
                        >
                          {isSelected && <Check className="w-3.5 h-3.5 text-[#D4AF37] stroke-[3]" />}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Step 3: Style & Accommodation Tier */}
              <div className="bg-[#F8F5EE] border border-[#D4AF37]/30 rounded-2xl p-6 sm:p-8 shadow-ceylon">
                <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-[#D4AF37] block mb-2">
                  03. Living Standards
                </span>
                <h3 className="font-serif text-2xl font-semibold text-[#0F382A] mb-4">
                  Estate Tier & Mobility
                </h3>

                <div className="space-y-5">
                  <div>
                    <label className="block text-xs font-semibold text-[#1A202C] mb-2 uppercase tracking-wider">
                      Sanctuary Tier
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {[
                        { title: 'Signature Heritage Planters', sub: 'Historic colonial bungalows with butlers' },
                        { title: 'Private Modernist Villas', sub: 'Geoffrey Bawa inspired pavilions' },
                        { title: 'Royal Governor Suites', sub: 'Master residences with dedicated staff' },
                      ].map((t) => (
                        <div
                          key={t.title}
                          onClick={() => setTier(t.title)}
                          className={`p-4 rounded-xl border cursor-pointer transition-all flex flex-col justify-between ${
                            tier === t.title
                              ? 'bg-[#FAF7F0] border-[#0F382A] ring-1 ring-[#D4AF37]/50'
                              : 'bg-[#FDFBF7] border-[#D4AF37]/25 hover:border-[#D4AF37]/60'
                          }`}
                        >
                          <div>
                            <span className="text-xs font-semibold text-[#0F382A] block mb-1">
                              {t.title}
                            </span>
                            <span className="text-[11px] text-[#717974] leading-relaxed block">
                              {t.sub}
                            </span>
                          </div>
                          <div className="mt-3 flex justify-end">
                            <div
                              className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                                tier === t.title ? 'border-[#0F382A] bg-[#0F382A]' : 'border-[#717974]'
                              }`}
                            >
                              {tier === t.title && <div className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#1A202C] mb-2 uppercase tracking-wider">
                      Ground & Air Transport
                    </label>
                    <select
                      value={transport}
                      onChange={(e) => setTransport(e.target.value)}
                      className="w-full bg-[#FDFBF7] border border-[#1A202C]/15 rounded-lg py-2.5 px-3 text-sm text-[#1A202C] focus:border-[#0F382A] focus:outline-none focus:ring-1 focus:ring-[#D4AF37]"
                    >
                      <option value="Scenic Vintage Rail + Executive SUV">
                        Scenic Vintage Rail Car + Executive Chauffeur SUV
                      </option>
                      <option value="Helicopter & Floatplane Island Hopping">
                        Helicopter & Floatplane Direct Island Hopping
                      </option>
                      <option value="Private Executive Hybrid SUV Only">
                        Private Executive Hybrid SUV Only
                      </option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Step 4: Curated Privileges */}
              <div className="bg-[#F8F5EE] border border-[#D4AF37]/30 rounded-2xl p-6 sm:p-8 shadow-ceylon">
                <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-[#D4AF37] block mb-2">
                  04. Bespoke Privileges
                </span>
                <h3 className="font-serif text-2xl font-semibold text-[#0F382A] mb-4">
                  Exclusive Concierge Commissions
                </h3>

                <div className="space-y-3">
                  {[
                    {
                      label: 'Helicopter scenic flight over Sigiriya and tea valley waterfalls',
                      cost: '+$2,400',
                      state: privilegeHeli,
                      toggle: () => setPrivilegeHeli(!privilegeHeli),
                    },
                    {
                      label: 'Private Ceylon Tea Sommelier master cupping & vintage harvest flight',
                      cost: '+$450',
                      state: privilegeTeaMaster,
                      toggle: () => setPrivilegeTeaMaster(!privilegeTeaMaster),
                    },
                    {
                      label: 'Senior Wildlife Warden private Land Cruiser tracker for Yala Block 1',
                      cost: '+$650',
                      state: privilegeNaturalist,
                      toggle: () => setPrivilegeNaturalist(!privilegeNaturalist),
                    },
                    {
                      label: 'Private twin-hull catamaran blue whale pelagic charter with marine biologist',
                      cost: '+$1,200',
                      state: privilegeWhaleYacht,
                      toggle: () => setPrivilegeWhaleYacht(!privilegeWhaleYacht),
                    },
                  ].map((priv, idx) => (
                    <div
                      key={idx}
                      onClick={priv.toggle}
                      className="flex items-center justify-between p-3.5 rounded-xl bg-[#FDFBF7] border border-[#D4AF37]/25 hover:border-[#D4AF37] cursor-pointer transition-all"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-5 h-5 rounded flex items-center justify-center border transition-colors ${
                            priv.state
                              ? 'bg-[#0F382A] border-[#D4AF37]'
                              : 'bg-[#FDFBF7] border-[#717974]'
                          }`}
                        >
                          {priv.state && <Check className="w-3.5 h-3.5 text-[#D4AF37] stroke-[3]" />}
                        </div>
                        <span className="text-xs sm:text-sm font-medium text-[#1A202C]">
                          {priv.label}
                        </span>
                      </div>
                      <span className="text-xs font-mono font-semibold text-[#735c00]">
                        {priv.cost}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Live Dossier & Investment Summary (Sticky Sidebar) */}
            <div className="lg:col-span-4 sticky top-28 space-y-6">
              <div className="bg-[#F8F5EE] border border-[#D4AF37]/30 border-t-4 border-t-[#D4AF37] rounded-2xl p-6 sm:p-8 shadow-ceylon">
                <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[#D4AF37] block mb-2">
                  Real-Time Commission Appraisal
                </span>

                <h3 className="font-serif text-2xl font-semibold text-[#0F382A] mb-4">
                  Bespoke Dossier Summary
                </h3>

                <div className="space-y-3 pb-6 border-b border-[#D4AF37]/20 text-xs text-[#414844]">
                  <div className="flex justify-between">
                    <span className="text-[#717974]">Duration:</span>
                    <span className="font-semibold text-[#0F382A]">{duration} Days / {duration - 1} Nights</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#717974]">Season:</span>
                    <span className="font-medium text-[#0F382A]">{season.split('(')[0]}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#717974]">Party Size:</span>
                    <span className="font-medium text-[#0F382A]">{guests} {guests === 1 ? 'Guest' : 'Guests'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#717974]">Sanctuary Tier:</span>
                    <span className="font-medium text-[#0F382A]">{tier.split(' ')[0]}</span>
                  </div>
                  <div>
                    <span className="text-[#717974] block mb-1">Mapped Route:</span>
                    <div className="space-y-1 pl-2">
                      {selectedRegions.map((r, i) => (
                        <div key={i} className="text-[#0F382A] flex items-center gap-1.5">
                          <span className="text-[#D4AF37] text-[10px]">✦</span>
                          <span className="truncate">{r}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Investment Total with Tabular Figures */}
                <div className="py-6 border-b border-[#D4AF37]/20">
                  <span className="text-[11px] text-[#717974] block uppercase tracking-wider mb-1">
                    Estimated Total Commission
                  </span>
                  <div className="flex items-baseline gap-2">
                    <span className="font-serif text-3xl sm:text-4xl font-semibold text-[#0F382A] tabular-nums">
                      ${totalInvestmentUsd.toLocaleString()}
                    </span>
                    <span className="text-xs text-[#717974]">USD</span>
                  </div>
                  <div className="text-xs font-mono text-[#735c00] mt-1">
                    Approx. ${perGuestUsd.toLocaleString()} USD per guest
                  </div>
                </div>

                {/* Dispatch Button */}
                <div className="pt-6 space-y-3">
                  <button
                    onClick={() => onOpenBookingWithCustomPlan(bespokeSummary)}
                    className="w-full py-3.5 px-6 rounded-lg bg-[#0F382A] text-[#FDFBF7] text-sm font-semibold tracking-wide hover:bg-[#144234] hover:border hover:border-[#D4AF37] transition-all cursor-pointer shadow-sm text-center block"
                  >
                    Submit Custom Blueprint
                  </button>

                  <p className="text-[11px] text-[#717974] text-center">
                    All blueprints reviewed by our senior journey curators within 24 hours.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
