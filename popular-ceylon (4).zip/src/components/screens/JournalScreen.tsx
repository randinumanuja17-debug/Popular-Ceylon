import React, { useState } from 'react';
import { JournalArticle } from '../../types';
import { JOURNAL_ARTICLES } from '../../data/ceylonData';
import { BookOpen, Sparkles, Clock, ArrowRight, Share2, Bookmark } from 'lucide-react';

interface JournalScreenProps {
  onExploreExpedition: () => void;
}

export const JournalScreen: React.FC<JournalScreenProps> = ({
  onExploreExpedition,
}) => {
  const [selectedArticleId, setSelectedArticleId] = useState<string>(JOURNAL_ARTICLES[0].id);

  const activeArticle =
    JOURNAL_ARTICLES.find((a) => a.id === selectedArticleId) || JOURNAL_ARTICLES[0];

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-[#1A202C]">
      {/* Editorial Header */}
      <section className="pt-12 pb-14 md:pt-16 md:pb-20 border-b border-[#D4AF37]/20">
        <div className="max-w-[1440px] mx-auto px-6 md:px-12 lg:px-16">
          <div className="max-w-3xl">
            <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[#D4AF37] block mb-3">
              Editorial Dispatches & Island Lore
            </span>
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-medium tracking-tight text-[#0F382A] leading-tight mb-6">
              The Ceylon Journal
            </h1>
            <p className="text-base sm:text-lg text-[#414844] leading-relaxed">
              Monographs on tea terroir, architectural tropical modernism, and the natural history
              of the Indian Ocean’s teardrop jewel.
            </p>
          </div>
        </div>
      </section>

      {/* Main Journal Article Reader */}
      <section className="py-12 md:py-16">
        <div className="max-w-[1440px] mx-auto px-6 md:px-12 lg:px-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            {/* Active Article Reading Column */}
            <article className="lg:col-span-8 bg-[#F8F5EE] border border-[#D4AF37]/30 rounded-2xl p-6 sm:p-10 md:p-12 shadow-ceylon">
              {/* Unboxed Metadata (Zero-pill discipline) */}
              <div className="flex flex-wrap items-center gap-2.5 text-xs text-[#717974] mb-4">
                <span className="font-semibold uppercase tracking-[0.12em] text-[#D4AF37]">
                  {activeArticle.category}
                </span>
                <span aria-hidden="true" className="text-[#D4AF37]">·</span>
                <span>{activeArticle.publishDate}</span>
                <span aria-hidden="true" className="text-[#D4AF37]">·</span>
                <span>{activeArticle.readTime}</span>
              </div>

              {/* Headline */}
              <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-medium text-[#0F382A] mb-6 leading-tight">
                {activeArticle.title}
              </h2>

              {/* Author attribution */}
              <div className="flex items-center gap-3 pb-6 mb-8 border-b border-[#D4AF37]/20 text-xs text-[#414844]">
                <div>
                  <span className="font-serif font-bold text-[#0F382A] block text-sm">
                    {activeArticle.author}
                  </span>
                  <span className="text-[#717974]">{activeArticle.authorTitle}</span>
                </div>
              </div>

              {/* Featured Photographic Frame */}
              <div className="mb-10 rounded-xl overflow-hidden border border-[#D4AF37]/30 h-80 sm:h-96 relative">
                <img
                  src={activeArticle.heroImage}
                  alt={activeArticle.title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Pull Quote Component (Playfair Display) */}
              <blockquote className="my-10 p-6 md:p-8 bg-[#FAF7F0] border-l-4 border-[#D4AF37] rounded-r-xl">
                <p className="font-serif italic text-xl sm:text-2xl text-[#0F382A] leading-relaxed">
                  {activeArticle.pullQuote}
                </p>
              </blockquote>

              {/* Prose Content */}
              <div className="space-y-6 text-base sm:text-lg leading-relaxed text-[#1A202C]">
                {activeArticle.content.map((paragraph, idx) => (
                  <p key={idx} className="leading-relaxed">
                    {paragraph}
                  </p>
                ))}
              </div>

              {/* Article Footer & Expedition Link */}
              <div className="mt-12 pt-8 border-t border-[#D4AF37]/20 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="text-xs text-[#717974]">
                  Published by Popular Ceylon Editorial Trust · Colombo & Hatton
                </div>

                <button
                  onClick={onExploreExpedition}
                  className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#0F382A] hover:text-[#184c3b] group cursor-pointer"
                >
                  <span>Experience this in our Expeditions</span>
                  <ArrowRight className="w-4 h-4 text-[#D4AF37] group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </article>

            {/* Sidebar of Other Journal Monographs */}
            <aside className="lg:col-span-4 space-y-6 sticky top-28">
              <div className="bg-[#F8F5EE] border border-[#D4AF37]/30 rounded-2xl p-6 sm:p-8 shadow-ceylon">
                <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[#D4AF37] block mb-2">
                  Chronicle Archives
                </span>
                <h3 className="font-serif text-2xl font-semibold text-[#0F382A] mb-6">
                  Curated Monographs
                </h3>

                <div className="space-y-5">
                  {JOURNAL_ARTICLES.map((article) => {
                    const isSelected = article.id === activeArticle.id;
                    return (
                      <div
                        key={article.id}
                        onClick={() => {
                          setSelectedArticleId(article.id);
                          window.scrollTo({ top: 380, behavior: 'smooth' });
                        }}
                        className={`p-4 rounded-xl border cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-[#FAF7F0] border-[#0F382A] ring-1 ring-[#D4AF37]/40'
                            : 'bg-[#FDFBF7] border-[#D4AF37]/20 hover:border-[#D4AF37]/60'
                        }`}
                      >
                        <div className="flex items-center gap-2 text-[10px] text-[#717974] mb-1.5">
                          <span className="font-semibold uppercase tracking-wider text-[#D4AF37]">
                            {article.category}
                          </span>
                          <span>·</span>
                          <span>{article.readTime}</span>
                        </div>
                        <h4 className="font-serif text-base font-semibold text-[#0F382A] mb-2 leading-snug">
                          {article.title}
                        </h4>
                        <p className="text-xs text-[#414844] line-clamp-2 leading-relaxed">
                          {article.excerpt}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </div>
  );
};
