import React, { useState } from 'react';
import { Destination } from '../../types';
import { DESTINATIONS } from '../../data/ceylonData';
import { MapPin, Sun, CloudRain, Mountain, Compass, ArrowRight } from 'lucide-react';

interface DestinationsScreenProps {
  onSelectDestinationForItinerary: (destination: Destination) => void;
  onOpenBooking: () => void;
}

export const DestinationsScreen: React.FC<DestinationsScreenProps> = ({
  onSelectDestinationForItinerary,
  onOpenBooking,
}) => {
  const [selectedDestId, setSelectedDestId] = useState<string>(DESTINATIONS[0].id);

  const selectedDestination =
    DESTINATIONS.find((d) => d.id === selectedDestId) || DESTINATIONS[0];

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-[#1A202C]">
      {/* Header */}
      <section className="pt-12 pb-14 md:pt-16 md:pb-20 border-b border-[#D4AF37]/20">
        <div className="max-w-[1440px] mx-auto px-6 md:px-12 lg:px-16">
          <div className="max-w-3xl">
            <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[#D4AF37] block mb-3">
              Geographic Cartography
            </span>
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-medium tracking-tight text-[#0F382A] leading-tight mb-6">
              The Seven Terrains of Ceylon
            </h1>
            <p className="text-base sm:text-lg text-[#414844] leading-relaxed">
              From mist-drenched cloud forests at 2,000 meters to golden Indian Ocean coral reefs
              and dry-zone savanna scrublands. Explore our hand-mapped sanctuaries.
            </p>
          </div>
        </div>
      </section>

      {/* Main Interactive Map & Region Guide */}
      <section className="py-12 md:py-16">
        <div className="max-w-[1440px] mx-auto px-6 md:px-12 lg:px-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start mb-16">
            {/* Interactive Island Map Canvas Graphic */}
            <div className="lg:col-span-5 bg-[#F8F5EE] border border-[#D4AF37]/30 rounded-2xl p-6 sm:p-8 shadow-ceylon">
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#D4AF37]/20">
                <div className="flex items-center gap-2">
                  <Compass className="w-4 h-4 text-[#D4AF37]" />
                  <span className="font-serif text-base font-semibold text-[#0F382A]">
                    Ceylon Archipelago Map
                  </span>
                </div>
                <span className="text-[11px] text-[#717974] font-mono">
                  8° N, 81° E
                </span>
              </div>

              {/* Stylized Island Map Graphic */}
              <div className="relative aspect-[3/4] bg-[#e8eeff]/40 rounded-xl overflow-hidden border border-[#D4AF37]/20 flex items-center justify-center p-4">
                {/* SVG Island Contour */}
                <svg
                  viewBox="0 0 300 400"
                  className="w-full h-full max-h-[380px] drop-shadow-md select-none"
                >
                  <defs>
                    <linearGradient id="islandGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#FAF7F0" />
                      <stop offset="50%" stopColor="#F1F5E8" />
                      <stop offset="100%" stopColor="#EAF1E6" />
                    </linearGradient>
                  </defs>

                  {/* Sri Lanka teardrop landmass */}
                  <path
                    d="M 150 40 
                       C 175 60, 200 90, 210 130 
                       C 220 180, 230 220, 210 270 
                       C 195 310, 165 350, 140 365 
                       C 115 350, 85 310, 75 260 
                       C 65 210, 75 160, 95 110 
                       C 115 70, 135 45, 150 40 Z"
                    fill="url(#islandGrad)"
                    stroke="#D4AF37"
                    strokeWidth="1.5"
                  />

                  {/* Central Highlands contour ring */}
                  <ellipse
                    cx="150"
                    cy="235"
                    rx="40"
                    ry="35"
                    fill="#0F382A"
                    fillOpacity="0.08"
                    stroke="#0F382A"
                    strokeWidth="1"
                    strokeDasharray="3 3"
                  />
                  <text
                    x="150"
                    y="240"
                    textAnchor="middle"
                    fill="#0F382A"
                    fontSize="9"
                    fontFamily="Playfair Display"
                    fontWeight="bold"
                  >
                    Highlands
                  </text>

                  {/* Route connection lines */}
                  <path
                    d="M 120 310 Q 150 240 150 170"
                    fill="none"
                    stroke="#D4AF37"
                    strokeWidth="1"
                    strokeDasharray="2 3"
                  />

                  {/* Interactive Region Pins */}
                  {DESTINATIONS.map((dest) => {
                    const isSelected = dest.id === selectedDestId;
                    const mapX = (dest.coordinates.x / 100) * 300;
                    const mapY = (dest.coordinates.y / 100) * 400;

                    return (
                      <g
                        key={dest.id}
                        className="cursor-pointer transition-transform duration-200"
                        onClick={() => setSelectedDestId(dest.id)}
                      >
                        {/* Ripple ping if selected */}
                        {isSelected && (
                          <circle
                            cx={mapX}
                            cy={mapY}
                            r="14"
                            fill="#D4AF37"
                            fillOpacity="0.25"
                            className="animate-ping origin-center"
                          />
                        )}
                        <circle
                          cx={mapX}
                          cy={mapY}
                          r={isSelected ? "9" : "6"}
                          fill={isSelected ? "#0F382A" : "#D4AF37"}
                          stroke="#FDFBF7"
                          strokeWidth="2"
                        />
                        <circle
                          cx={mapX}
                          cy={mapY}
                          r="3"
                          fill={isSelected ? "#D4AF37" : "#0F382A"}
                        />
                      </g>
                    );
                  })}
                </svg>

                <div className="absolute bottom-3 left-3 text-[10px] text-[#717974] bg-[#FDFBF7]/90 px-2 py-1 rounded border border-[#D4AF37]/30">
                  Tap waypoints to inspect region
                </div>
              </div>

              {/* Destination Selector Buttons */}
              <div className="mt-6 space-y-2">
                {DESTINATIONS.map((d) => {
                  const isSelected = d.id === selectedDestId;
                  return (
                    <button
                      key={d.id}
                      onClick={() => setSelectedDestId(d.id)}
                      className={`w-full p-3 rounded-lg text-left transition-all flex items-center justify-between cursor-pointer border ${
                        isSelected
                          ? 'bg-[#0F382A] text-[#FDFBF7] border-[#0F382A]'
                          : 'bg-[#FDFBF7] text-[#1A202C] border-[#D4AF37]/20 hover:border-[#D4AF37]/60'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <MapPin
                          className={`w-3.5 h-3.5 ${
                            isSelected ? 'text-[#D4AF37]' : 'text-[#717974]'
                          }`}
                        />
                        <span className="text-xs md:text-sm font-medium">
                          {d.name}
                        </span>
                      </div>
                      <span
                        className={`text-[11px] font-mono ${
                          isSelected ? 'text-[#D4AF37]' : 'text-[#717974]'
                        }`}
                      >
                        {d.elevation.split('–')[0]}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Selected Destination Spotlight Dossier */}
            <div className="lg:col-span-7 bg-[#F8F5EE] border border-[#D4AF37]/30 rounded-2xl overflow-hidden shadow-ceylon">
              {/* Destination Hero Image */}
              <div className="h-72 md:h-80 overflow-hidden relative group">
                <img
                  src={selectedDestination.heroImage}
                  alt={selectedDestination.name}
                  className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent flex flex-col justify-end p-6 sm:p-8">
                  <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-[#F4E298] mb-1">
                    {selectedDestination.sinhalaName}
                  </span>
                  <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl font-semibold text-[#FDFBF7]">
                    {selectedDestination.name}
                  </h2>
                </div>
              </div>

              {/* Dossier Body */}
              <div className="p-6 sm:p-8 md:p-10 space-y-6">
                {/* Micro Metadata Strip */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-4 rounded-xl bg-[#FDFBF7] border border-[#D4AF37]/25 text-xs text-[#414844]">
                  <div>
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-[#717974] block">
                      Elevation
                    </span>
                    <span className="font-mono font-medium text-[#0F382A]">
                      {selectedDestination.elevation}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-[#717974] block">
                      Atmosphere
                    </span>
                    <span className="font-medium text-[#0F382A]">
                      {selectedDestination.climate.split(',')[0]}
                    </span>
                  </div>
                  <div className="col-span-2 sm:col-span-1">
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-[#717974] block">
                      Optimal Window
                    </span>
                    <span className="font-medium text-[#0F382A]">
                      {selectedDestination.bestMonths}
                    </span>
                  </div>
                </div>

                {/* Narrative Summary */}
                <p className="text-[15px] sm:text-base leading-relaxed text-[#414844]">
                  {selectedDestination.summary}
                </p>

                {/* Editorial Historian Insight Box */}
                <div className="p-5 rounded-xl bg-[#FAF7F0] border-l-4 border-[#D4AF37] text-sm text-[#414844] italic">
                  <span className="font-serif font-semibold text-[#0F382A] not-italic block mb-1">
                    Curator’s Field Note:
                  </span>
                  "{selectedDestination.editorialInsight}"
                </div>

                {/* Curated Highlights List with Golden Diamond Glyphs */}
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-[0.12em] text-[#0F382A] mb-3">
                    Uncharted Highlights & Encounters
                  </h4>
                  <ul className="space-y-2.5 text-sm text-[#1A202C]">
                    {selectedDestination.highlights.map((h, i) => (
                      <li key={i} className="flex items-start gap-2.5">
                        <span className="text-[#D4AF37] select-none text-xs mt-1 shrink-0">✦</span>
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Action CTAs */}
                <div className="pt-6 border-t border-[#D4AF37]/20 flex flex-wrap items-center justify-between gap-4">
                  <button
                    onClick={() => onSelectDestinationForItinerary(selectedDestination)}
                    className="px-6 py-3 rounded-lg bg-[#0F382A] text-[#FDFBF7] text-xs sm:text-sm font-semibold hover:bg-[#144234] hover:border hover:border-[#D4AF37] transition-all cursor-pointer flex items-center gap-2"
                  >
                    <span>Build Route Including {selectedDestination.name.split('&')[0]}</span>
                    <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
                  </button>

                  <button
                    onClick={onOpenBooking}
                    className="px-5 py-3 rounded-lg text-xs sm:text-sm font-semibold text-[#0F382A] border border-[#D4AF37] hover:bg-[#D4AF37]/10 transition-colors cursor-pointer"
                  >
                    Direct Concierge Inquiry
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Destination Gallery Cards Grid */}
          <div className="pt-8">
            <h3 className="font-serif text-2xl font-semibold text-[#0F382A] mb-6">
              All Island Destination Chapters
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {DESTINATIONS.map((dest) => (
                <div
                  key={dest.id}
                  onClick={() => {
                    setSelectedDestId(dest.id);
                    window.scrollTo({ top: 380, behavior: 'smooth' });
                  }}
                  className="bg-[#F8F5EE] border border-[#D4AF37]/25 rounded-2xl overflow-hidden group cursor-pointer shadow-ceylon hover:shadow-ceylon-lg transition-all duration-300"
                >
                  <div className="h-52 overflow-hidden relative">
                    <img
                      src={dest.heroImage}
                      alt={dest.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-3 right-3 bg-[#0F382A]/85 backdrop-blur-md px-2.5 py-1 rounded text-[11px] font-mono text-[#F4E298] border border-[#D4AF37]/30">
                      {dest.elevation.split('–')[0]}
                    </div>
                  </div>

                  <div className="p-6">
                    <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-[#D4AF37] block mb-1">
                      {dest.region}
                    </span>
                    <h4 className="font-serif text-xl font-semibold text-[#0F382A] mb-2 group-hover:text-[#184c3b] transition-colors">
                      {dest.name}
                    </h4>
                    <p className="text-xs sm:text-sm text-[#414844] line-clamp-2 leading-relaxed mb-4">
                      {dest.summary}
                    </p>

                    <div className="pt-3 border-t border-[#D4AF37]/20 flex items-center justify-between text-xs">
                      <span className="text-[#717974]">{dest.bestMonths}</span>
                      <span className="text-[#0F382A] font-semibold group-hover:translate-x-1 transition-transform inline-flex items-center gap-1">
                        Explore <ArrowRight className="w-3 h-3 text-[#D4AF37]" />
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
