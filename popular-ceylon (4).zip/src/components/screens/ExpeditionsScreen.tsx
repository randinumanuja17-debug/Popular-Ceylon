import React, { useState } from 'react';
import { Expedition, ScreenType } from '../../types';
import { EXPEDITIONS } from '../../data/ceylonData';
import { ItineraryMilestoneBar } from '../ItineraryMilestoneBar';
import { ExpeditionTimeline } from '../ExpeditionTimeline';
import { Sparkles, Calendar, Clock, Users, ArrowRight, ShieldCheck, Mountain } from 'lucide-react';

interface ExpeditionsScreenProps {
  onOpenBookingWithExpedition: (expedition: Expedition) => void;
  onNavigateToBespoke: () => void;
}

export const ExpeditionsScreen: React.FC<ExpeditionsScreenProps> = ({
  onOpenBookingWithExpedition,
  onNavigateToBespoke,
}) => {
  const [activeExpeditionId, setActiveExpeditionId] = useState<string>(EXPEDITIONS[0].id);
  const [activeDay, setActiveDay] = useState<number>(1);

  const activeExpedition =
    EXPEDITIONS.find((e) => e.id === activeExpeditionId) || EXPEDITIONS[0];

  const handleSelectExpedition = (expeditionId: string) => {
    setActiveExpeditionId(expeditionId);
    setActiveDay(1);
    // Smoothly scroll to top of showcase
    window.scrollTo({ top: 400, behavior: 'smooth' });
  };

  const handleSelectDay = (day: number) => {
    setActiveDay(day);
    const element = document.getElementById(`day-${day}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-[#1A202C]">
      {/* Editorial Hero Section */}
      <section className="relative pt-12 pb-20 md:pt-16 md:pb-28 overflow-hidden border-b border-[#D4AF37]/20">
        <div className="max-w-[1440px] mx-auto px-6 md:px-12 lg:px-16">
          <div className="max-w-3xl">
            {/* Curated Kicker */}
            <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[#D4AF37] block mb-3">
              Curated Masterwork Itineraries
            </span>

            {/* Display Hero Title */}
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-medium tracking-tight text-[#0F382A] leading-[1.12] mb-6 text-balance">
              Where untamed jungle meets timeless colonial elegance.
            </h1>

            <p className="text-base sm:text-lg text-[#414844] leading-relaxed mb-8 max-w-2xl">
              Each Popular Ceylon journey is privately architected for inquisitive travelers,
              connecting high-grown tea mist, sacred monoliths, and coastal leopard reserves
              with peerless personal hospitality.
            </p>

            {/* Expedition Selection Segmented Tabs */}
            <div className="flex flex-wrap items-center gap-2 p-1.5 bg-[#F8F5EE] border border-[#D4AF37]/30 rounded-xl inline-flex">
              {EXPEDITIONS.map((exp) => {
                const isSelected = exp.id === activeExpedition.id;
                return (
                  <button
                    key={exp.id}
                    onClick={() => handleSelectExpedition(exp.id)}
                    className={`px-4 py-2.5 rounded-lg text-xs md:text-sm font-medium transition-all duration-200 cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#0F382A] ${
                      isSelected
                        ? 'bg-[#0F382A] text-[#FDFBF7] shadow-sm'
                        : 'text-[#414844] hover:text-[#0F382A] hover:bg-[#FDFBF7]'
                    }`}
                  >
                    {exp.title}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Flagship Active Expedition Showcase Section */}
      <section className="py-12 md:py-16">
        <div className="max-w-[1440px] mx-auto px-6 md:px-12 lg:px-16">
          {/* Headline & Overview Block */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start mb-12">
            <div className="lg:col-span-8">
              <div className="flex items-center gap-3 text-xs text-[#717974] mb-3">
                <span className="font-semibold uppercase tracking-[0.12em] text-[#D4AF37]">
                  {activeExpedition.travelStyle}
                </span>
                <span aria-hidden="true">·</span>
                <span>{activeExpedition.durationDays} Days / {activeExpedition.durationDays - 1} Nights</span>
                <span aria-hidden="true">·</span>
                <span>Private 2 to {activeExpedition.maxGuests} Guests</span>
              </div>

              <h2 className="font-serif text-3xl sm:text-4xl md:text-[44px] font-medium text-[#0F382A] mb-4 leading-tight">
                {activeExpedition.title}
              </h2>

              <p className="font-serif italic text-lg sm:text-xl text-[#735c00] mb-6">
                "{activeExpedition.subtitle}"
              </p>

              <p className="text-[16px] text-[#414844] leading-relaxed mb-6">
                {activeExpedition.overview}
              </p>

              {/* Route Summary & Elevation Pill Strip */}
              <div className="flex flex-wrap items-center gap-4 py-3 px-4 rounded-xl bg-[#F8F5EE] border border-[#D4AF37]/25 text-xs text-[#414844]">
                <div>
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-[#717974] block">
                    Traversed Route
                  </span>
                  <span className="font-medium text-[#0F382A]">
                    {activeExpedition.routeSummary}
                  </span>
                </div>
                <div className="h-6 w-[1px] bg-[#D4AF37]/30 hidden sm:block" />
                <div>
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-[#717974] block">
                    Altitude Profile
                  </span>
                  <span className="font-mono text-[#0F382A]">
                    {activeExpedition.elevationRange}
                  </span>
                </div>
                <div className="h-6 w-[1px] bg-[#D4AF37]/30 hidden sm:block" />
                <div>
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-[#717974] block">
                    Prime Season
                  </span>
                  <span className="text-[#0F382A] font-medium">
                    {activeExpedition.season}
                  </span>
                </div>
              </div>
            </div>

            {/* Investment & Reservation Capsule */}
            <div className="lg:col-span-4 bg-[#F8F5EE] border border-[#D4AF37]/30 rounded-2xl p-6 sm:p-8 shadow-ceylon">
              <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-[#D4AF37] block mb-2">
                All-Inclusive Private Expedition
              </span>

              <div className="mb-4">
                <span className="text-xs text-[#717974]">Starting from</span>
                <div className="flex items-baseline gap-2">
                  <span className="font-serif text-3xl sm:text-4xl font-semibold text-[#0F382A] tabular-nums">
                    ${activeExpedition.startingPriceUsd.toLocaleString()}
                  </span>
                  <span className="text-xs text-[#717974]">
                    USD / guest (approx. £{activeExpedition.startingPriceGbp.toLocaleString()})
                  </span>
                </div>
              </div>

              <div className="text-xs text-[#414844] space-y-2 mb-6 pb-6 border-b border-[#D4AF37]/20">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#10B981]" />
                  <span>Personal chauffeur, vintage rail & butler included</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-[#10B981]" />
                  <span>Fully customizable dates & private aircraft hops</span>
                </div>
              </div>

              <div className="space-y-3">
                <button
                  onClick={() => onOpenBookingWithExpedition(activeExpedition)}
                  className="w-full py-3.5 px-6 rounded-lg bg-[#0F382A] text-[#FDFBF7] text-sm font-semibold tracking-wide hover:bg-[#144234] hover:border hover:border-[#D4AF37] transition-all cursor-pointer shadow-sm text-center block"
                >
                  Reserve This Expedition
                </button>

                <button
                  onClick={onNavigateToBespoke}
                  className="w-full py-3 px-6 rounded-lg bg-transparent border border-[#D4AF37] text-[#0F382A] text-sm font-semibold hover:bg-[#D4AF37]/10 transition-colors cursor-pointer text-center block"
                >
                  Customize in Journey Builder
                </button>
              </div>
            </div>
          </div>

          {/* Featured Imagery Tri-Frame */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mb-16 rounded-2xl overflow-hidden">
            <div className="md:col-span-8 h-[340px] md:h-[480px] overflow-hidden rounded-xl border border-[#D4AF37]/20 relative group">
              <img
                src={activeExpedition.heroImage}
                alt={activeExpedition.title}
                className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-6">
                <span className="text-[#FDFBF7] text-sm font-medium">
                  {activeExpedition.routeSummary}
                </span>
              </div>
            </div>

            <div className="md:col-span-4 flex flex-col gap-4 h-[480px]">
              {activeExpedition.galleryImages.slice(0, 2).map((img, idx) => (
                <div
                  key={idx}
                  className="flex-1 overflow-hidden rounded-xl border border-[#D4AF37]/20 relative group"
                >
                  <img
                    src={img}
                    alt={`${activeExpedition.title} preview ${idx + 1}`}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Signature Component: ITINERARY MILESTONE BAR */}
          <div className="mb-14">
            <ItineraryMilestoneBar
              days={activeExpedition.days}
              activeDay={activeDay}
              onSelectDay={handleSelectDay}
            />
          </div>

          {/* Expedition Curated Privileges Box */}
          <div className="mb-16 bg-[#F8F5EE] border border-[#D4AF37]/30 rounded-2xl p-6 md:p-8">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-4 h-4 text-[#D4AF37]" />
              <h3 className="font-serif text-xl font-semibold text-[#0F382A]">
                Popular Ceylon Inclusions & Curated Privileges
              </h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {activeExpedition.includedPrivileges.map((privilege, i) => (
                <div key={i} className="flex items-start gap-3 text-sm text-[#414844]">
                  <span className="text-[#D4AF37] select-none text-xs mt-1">✦</span>
                  <span className="leading-relaxed">{privilege}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Day-by-Day Timeline Itinerary */}
          <div className="mb-20">
            <div className="mb-8">
              <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-[#D4AF37] block mb-1">
                Detailed Expedition Log
              </span>
              <h3 className="font-serif text-3xl font-semibold text-[#0F382A]">
                The Day-by-Day Itinerary
              </h3>
            </div>

            <ExpeditionTimeline
              days={activeExpedition.days}
              activeDay={activeDay}
              onSelectDay={handleSelectDay}
            />
          </div>

          {/* Other Expeditions in the Collection (Cards Grid) */}
          <div className="pt-12 border-t border-[#D4AF37]/25">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
              <div>
                <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-[#D4AF37] block mb-1">
                  Alternative Island Chapters
                </span>
                <h3 className="font-serif text-2xl md:text-3xl font-semibold text-[#0F382A]">
                  Explore Other Signature Collections
                </h3>
              </div>
              <button
                onClick={onNavigateToBespoke}
                className="inline-flex items-center gap-2 text-sm font-semibold text-[#0F382A] hover:text-[#184c3b] group cursor-pointer"
              >
                <span>Design custom itinerary from scratch</span>
                <ArrowRight className="w-4 h-4 text-[#D4AF37] group-hover:translate-x-1 transition-transform" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {EXPEDITIONS.filter((e) => e.id !== activeExpedition.id).map((other) => (
                <div
                  key={other.id}
                  onClick={() => handleSelectExpedition(other.id)}
                  className="bg-[#F8F5EE] border border-[#D4AF37]/30 rounded-2xl overflow-hidden group cursor-pointer shadow-ceylon hover:shadow-ceylon-lg transition-all duration-300 flex flex-col justify-between"
                >
                  <div className="h-64 overflow-hidden relative">
                    <img
                      src={other.heroImage}
                      alt={other.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-4 left-4 bg-[#FDFBF7]/90 backdrop-blur-md px-3 py-1 rounded text-xs font-semibold text-[#0F382A] border border-[#D4AF37]/40">
                      {other.durationDays} Days · {other.travelStyle}
                    </div>
                  </div>

                  <div className="p-6 md:p-8 flex-1 flex flex-col justify-between">
                    <div>
                      <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-[#D4AF37] block mb-1">
                        {other.routeSummary}
                      </span>
                      <h4 className="font-serif text-2xl font-semibold text-[#0F382A] mb-3 group-hover:text-[#184c3b] transition-colors">
                        {other.title}
                      </h4>
                      <p className="text-sm text-[#414844] line-clamp-3 mb-6 leading-relaxed">
                        {other.tagline}
                      </p>
                    </div>

                    <div className="pt-4 border-t border-[#D4AF37]/20 flex items-center justify-between">
                      <div>
                        <span className="text-[11px] text-[#717974] block">Investment from</span>
                        <span className="font-serif text-lg font-semibold text-[#0F382A]">
                          ${other.startingPriceUsd.toLocaleString()} USD
                        </span>
                      </div>

                      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#0F382A] group-hover:text-[#184c3b]">
                        View Expedition
                        <ArrowRight className="w-3.5 h-3.5 text-[#D4AF37]" />
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
