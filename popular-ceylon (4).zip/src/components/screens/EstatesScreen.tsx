import React, { useState } from 'react';
import { HeritageEstate } from '../../types';
import { HERITAGE_ESTATES } from '../../data/ceylonData';
import { BedDouble, Sparkles, MapPin, Calendar, Check, ArrowRight } from 'lucide-react';

interface EstatesScreenProps {
  onOpenBookingForEstate: (estate: HeritageEstate) => void;
}

export const EstatesScreen: React.FC<EstatesScreenProps> = ({
  onOpenBookingForEstate,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedEstate, setSelectedEstate] = useState<HeritageEstate | null>(null);

  const categories = [
    'All',
    'Colonial Tea Planter',
    'Tropical Modernism',
    'Private Safari Lodge',
    'Coastal Beachfront',
  ];

  const filteredEstates =
    selectedCategory === 'All'
      ? HERITAGE_ESTATES
      : HERITAGE_ESTATES.filter((e) => e.category === selectedCategory);

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-[#1A202C]">
      {/* Editorial Header */}
      <section className="pt-12 pb-14 md:pt-16 md:pb-20 border-b border-[#D4AF37]/20">
        <div className="max-w-[1440px] mx-auto px-6 md:px-12 lg:px-16">
          <div className="max-w-3xl">
            <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[#D4AF37] block mb-3">
              Sanctuary Living & Heritage Provenance
            </span>
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-medium tracking-tight text-[#0F382A] leading-tight mb-6">
              Planter Bungalows & Architectural Sanctuaries
            </h1>
            <p className="text-base sm:text-lg text-[#414844] leading-relaxed mb-8">
              A private portfolio of 19th-century colonial tea residencies, Geoffrey Bawa’s
              tropical modernist retreats, and ocean-facing pavilions where dedicated butlers
              maintain century-old rituals.
            </p>

            {/* Filter Tabs */}
            <div className="flex flex-wrap items-center gap-2 p-1.5 bg-[#F8F5EE] border border-[#D4AF37]/30 rounded-xl inline-flex">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-4 py-2 rounded-lg text-xs md:text-sm font-medium transition-all duration-200 cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#0F382A] ${
                    selectedCategory === cat
                      ? 'bg-[#0F382A] text-[#FDFBF7] shadow-sm'
                      : 'text-[#414844] hover:text-[#0F382A] hover:bg-[#FDFBF7]'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Estates Grid */}
      <section className="py-12 md:py-16">
        <div className="max-w-[1440px] mx-auto px-6 md:px-12 lg:px-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredEstates.map((estate) => (
              <div
                key={estate.id}
                className="bg-[#F8F5EE] border border-[#D4AF37]/30 rounded-2xl overflow-hidden shadow-ceylon hover:shadow-ceylon-lg transition-all duration-300 flex flex-col justify-between group"
              >
                <div>
                  {/* Image Frame */}
                  <div className="h-64 overflow-hidden relative">
                    <img
                      src={estate.heroImage}
                      alt={estate.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-3 left-3 bg-[#0F382A]/90 backdrop-blur-md px-2.5 py-1 rounded text-xs font-semibold text-[#FDFBF7] border border-[#D4AF37]/40">
                      Circa {estate.builtYear}
                    </div>
                    <div className="absolute top-3 right-3 bg-[#FDFBF7]/90 backdrop-blur-md px-2.5 py-1 rounded text-[11px] font-mono text-[#0F382A] border border-[#D4AF37]/40">
                      {estate.elevation}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-6 md:p-8">
                    <div className="flex items-center gap-2 text-xs text-[#717974] mb-2">
                      <span className="font-semibold uppercase tracking-[0.12em] text-[#D4AF37]">
                        {estate.category}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-[#10B981]" />
                        {estate.location}
                      </span>
                    </div>

                    <h3 className="font-serif text-2xl font-semibold text-[#0F382A] mb-3 group-hover:text-[#184c3b] transition-colors leading-snug">
                      {estate.name}
                    </h3>

                    <p className="text-xs text-[#717974] mb-4 italic">
                      Conceived by {estate.architectOrFounder}
                    </p>

                    <p className="text-sm text-[#414844] leading-relaxed mb-6">
                      {estate.description}
                    </p>

                    {/* Signature Experience Callout */}
                    <div className="p-3.5 rounded-xl bg-[#FAF7F0] border border-[#D4AF37]/30 mb-6">
                      <span className="text-[10px] font-semibold uppercase tracking-wider text-[#D4AF37] block mb-1">
                        Curated Signature Ritual
                      </span>
                      <p className="text-xs text-[#0F382A] leading-relaxed">
                        {estate.signatureExperience}
                      </p>
                    </div>

                    {/* Amenities Checklist with delicate golden diamonds */}
                    <div className="space-y-1.5 mb-6">
                      {estate.amenities.map((amenity, i) => (
                        <div key={i} className="flex items-center gap-2 text-xs text-[#414844]">
                          <span className="text-[#D4AF37] text-xs">✦</span>
                          <span>{amenity}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Footer with Pricing & Reservation Action */}
                <div className="p-6 md:p-8 pt-0 border-t border-[#D4AF37]/20 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-[#717974] block">Nightly Residence</span>
                    <span className="font-serif text-xl font-semibold text-[#0F382A]">
                      ${estate.startingNightlyUsd} <span className="text-xs text-[#717974] font-sans font-normal">USD</span>
                    </span>
                  </div>

                  <button
                    onClick={() => onOpenBookingForEstate(estate)}
                    className="px-5 py-2.5 rounded-lg bg-[#0F382A] text-[#FDFBF7] text-xs font-semibold hover:bg-[#144234] hover:border hover:border-[#D4AF37] transition-all cursor-pointer whitespace-nowrap"
                  >
                    Reserve Suite
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};
