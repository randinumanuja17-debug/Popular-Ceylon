import React, { useState } from 'react';
import { Expedition } from '../types';
import { X, Check, Calendar, Users, Shield, Sparkles } from 'lucide-react';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  expedition?: Expedition;
  preselectedExpeditionTitle?: string;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  expedition,
  preselectedExpeditionTitle,
}) => {
  const [selectedExpedition, setSelectedExpedition] = useState(
    preselectedExpeditionTitle || expedition?.title || 'The Tea Country Highland Passage'
  );
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [departureMonth, setDepartureMonth] = useState('January 2027');
  const [guestCount, setGuestCount] = useState(2);
  const [privilegeHelicopter, setPrivilegeHelicopter] = useState(false);
  const [privilegeTeaSommelier, setPrivilegeTeaSommelier] = useState(true);
  const [privilegePrivateChef, setPrivilegePrivateChef] = useState(true);
  const [specialRequests, setSpecialRequests] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [referenceCode, setReferenceCode] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const randomRef = `CEY-${Math.floor(100000 + Math.random() * 900000)}`;
    setReferenceCode(randomRef);
    setSubmitted(true);
  };

  const handleReset = () => {
    setSubmitted(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Dimmed backdrop */}
      <div
        className="fixed inset-0 bg-[#002217]/60 backdrop-blur-sm transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Modal Dialog Card (Tier 2 Elevation with Hairline Gold Highlight on Top Edge) */}
      <div className="relative w-full max-w-2xl bg-[#FDFBF7] rounded-2xl shadow-ceylon-lg border border-[#D4AF37]/30 border-t-2 border-t-[#D4AF37] overflow-hidden z-10 my-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg text-[#717974] hover:text-[#0F382A] hover:bg-[#F8F5EE] transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#0F382A]"
          aria-label="Close reservation modal"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div className="p-8 md:p-12 text-center">
            <div className="w-16 h-16 rounded-full bg-[#0F382A] text-[#D4AF37] flex items-center justify-center mx-auto mb-6 shadow-md border border-[#D4AF37]">
              <Sparkles className="w-8 h-8" />
            </div>
            <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-[#D4AF37] block mb-2">
              Bespoke Journey Reserved
            </span>
            <h3 className="font-serif text-3xl font-semibold text-[#0F382A] mb-4">
              Ayubowan, {fullName || 'Honoured Guest'}
            </h3>
            <p className="text-sm text-[#414844] max-w-md mx-auto mb-6 leading-relaxed">
              Your inquiry dossier has been delivered directly to the Senior Curator at Popular Ceylon. Your journey architect will contact you within 24 hours to finalize private aviation, estate suites, and vintage train reservations.
            </p>

            <div className="bg-[#F8F5EE] border border-[#D4AF37]/40 rounded-xl p-4 max-w-sm mx-auto mb-8 text-left">
              <div className="flex justify-between items-center text-xs pb-2 border-b border-[#D4AF37]/20">
                <span className="text-[#717974]">Dossier Reference:</span>
                <span className="font-mono font-bold text-[#0F382A]">{referenceCode}</span>
              </div>
              <div className="flex justify-between items-center text-xs pt-2">
                <span className="text-[#717974]">Selected Expedition:</span>
                <span className="font-medium text-[#0F382A] truncate max-w-[200px]">{selectedExpedition}</span>
              </div>
            </div>

            <button
              onClick={handleReset}
              className="px-8 py-3.5 rounded-lg bg-[#0F382A] text-[#FDFBF7] text-sm font-semibold hover:bg-[#144234] hover:border hover:border-[#D4AF37] transition-all cursor-pointer"
            >
              Return to Island Collections
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 md:p-10 max-h-[85vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="mb-6 pb-4 border-b border-[#D4AF37]/20">
              <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-[#D4AF37] block mb-1">
                Private Curation Request
              </span>
              <h3 className="font-serif text-2xl md:text-3xl font-semibold text-[#0F382A]">
                Reserve Your Ceylon Expedition
              </h3>
              <p className="text-xs md:text-sm text-[#414844] mt-1">
                Each journey is individually provisioned for discerning travelers. No shared groups.
              </p>
            </div>

            <div className="space-y-5">
              {/* Expedition Selection */}
              <div>
                <label className="block text-xs font-semibold text-[#1A202C] mb-1.5 uppercase tracking-wider">
                  Selected Itinerary or Collection
                </label>
                <select
                  value={selectedExpedition}
                  onChange={(e) => setSelectedExpedition(e.target.value)}
                  className="w-full bg-[#FDFBF7] border border-[#1A202C]/15 rounded-lg py-2.5 px-3.5 text-sm text-[#1A202C] focus:border-[#0F382A] focus:ring-2 focus:ring-[#D4AF37]/30 transition-all focus:outline-none"
                >
                  <option value="The Tea Country Highland Passage">
                    The Tea Country Highland Passage (8 Days)
                  </option>
                  <option value="Royal Kingdoms & Leopard Wilderness">
                    Royal Kingdoms & Leopard Wilderness (10 Days)
                  </option>
                  <option value="Southern Galle Serenade & Cinnamon Coast">
                    Southern Galle Serenade & Cinnamon Coast (7 Days)
                  </option>
                  <option value="Bespoke Private Island Commission">
                    Bespoke Private Island Commission (Tailor-made)
                  </option>
                </select>
              </div>

              {/* Guest & Timing Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#1A202C] mb-1.5 uppercase tracking-wider flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-[#D4AF37]" />
                    Anticipated Season
                  </label>
                  <select
                    value={departureMonth}
                    onChange={(e) => setDepartureMonth(e.target.value)}
                    className="w-full bg-[#FDFBF7] border border-[#1A202C]/15 rounded-lg py-2.5 px-3.5 text-sm text-[#1A202C] focus:border-[#0F382A] focus:ring-2 focus:ring-[#D4AF37]/30 transition-all focus:outline-none"
                  >
                    <option value="December 2026">December 2026 (Peak Season)</option>
                    <option value="January 2027">January 2027 (Highlands Bloom)</option>
                    <option value="February 2027">February 2027 (Dry Skies)</option>
                    <option value="March 2027">March 2027 (Ideal Coast & Safari)</option>
                    <option value="April 2027">April 2027 (Sinhala New Year)</option>
                    <option value="July 2027">July 2027 (Summer Hill Breeze)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1A202C] mb-1.5 uppercase tracking-wider flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-[#D4AF37]" />
                    Number of Traveling Guests
                  </label>
                  <div className="flex items-center gap-3 bg-[#FDFBF7] border border-[#1A202C]/15 rounded-lg py-1.5 px-3">
                    <button
                      type="button"
                      onClick={() => setGuestCount(Math.max(1, guestCount - 1))}
                      className="w-8 h-8 rounded bg-[#F8F5EE] border border-[#D4AF37]/30 text-[#0F382A] font-bold text-sm hover:bg-[#0F382A] hover:text-[#FDFBF7] transition-colors cursor-pointer"
                    >
                      -
                    </button>
                    <span className="flex-1 text-center font-mono font-semibold text-sm">
                      {guestCount} {guestCount === 1 ? 'Guest' : 'Guests'}
                    </span>
                    <button
                      type="button"
                      onClick={() => setGuestCount(Math.min(10, guestCount + 1))}
                      className="w-8 h-8 rounded bg-[#F8F5EE] border border-[#D4AF37]/30 text-[#0F382A] font-bold text-sm hover:bg-[#0F382A] hover:text-[#FDFBF7] transition-colors cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>

              {/* Personal Contact Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#1A202C] mb-1.5 uppercase tracking-wider">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Lady Eleanor Vance"
                    className="w-full bg-[#FDFBF7] border border-[#1A202C]/15 rounded-lg py-2.5 px-3.5 text-sm text-[#1A202C] focus:border-[#0F382A] focus:ring-2 focus:ring-[#D4AF37]/30 transition-all focus:outline-none placeholder:text-[#717974]/60"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1A202C] mb-1.5 uppercase tracking-wider">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="vance@heritage.co.uk"
                    className="w-full bg-[#FDFBF7] border border-[#1A202C]/15 rounded-lg py-2.5 px-3.5 text-sm text-[#1A202C] focus:border-[#0F382A] focus:ring-2 focus:ring-[#D4AF37]/30 transition-all focus:outline-none placeholder:text-[#717974]/60"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#1A202C] mb-1.5 uppercase tracking-wider">
                  Direct Phone or WhatsApp
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+44 7700 900123"
                  className="w-full bg-[#FDFBF7] border border-[#1A202C]/15 rounded-lg py-2.5 px-3.5 text-sm text-[#1A202C] focus:border-[#0F382A] focus:ring-2 focus:ring-[#D4AF37]/30 transition-all focus:outline-none placeholder:text-[#717974]/60"
                />
              </div>

              {/* Bespoke Privileges Selection with 20px custom checkboxes */}
              <div className="pt-2">
                <span className="block text-xs font-semibold text-[#0F382A] mb-2 uppercase tracking-wider">
                  Complimentary & Curated Privileges
                </span>

                <div className="space-y-2.5">
                  <label className="flex items-center gap-3 p-2.5 rounded-lg bg-[#F8F5EE] border border-[#D4AF37]/25 cursor-pointer hover:border-[#D4AF37]">
                    <div
                      onClick={() => setPrivilegeTeaSommelier(!privilegeTeaSommelier)}
                      className={`w-5 h-5 rounded flex items-center justify-center transition-colors border ${
                        privilegeTeaSommelier
                          ? 'bg-[#0F382A] border-[#D4AF37]'
                          : 'bg-[#FDFBF7] border-[#717974]'
                      }`}
                    >
                      {privilegeTeaSommelier && (
                        <Check className="w-3.5 h-3.5 text-[#D4AF37] stroke-[3]" />
                      )}
                    </div>
                    <span className="text-xs text-[#1A202C] font-medium">
                      Private Master Tea Sommelier cupping & rare vintage harvest tasting
                    </span>
                  </label>

                  <label className="flex items-center gap-3 p-2.5 rounded-lg bg-[#F8F5EE] border border-[#D4AF37]/25 cursor-pointer hover:border-[#D4AF37]">
                    <div
                      onClick={() => setPrivilegePrivateChef(!privilegePrivateChef)}
                      className={`w-5 h-5 rounded flex items-center justify-center transition-colors border ${
                        privilegePrivateChef
                          ? 'bg-[#0F382A] border-[#D4AF37]'
                          : 'bg-[#FDFBF7] border-[#717974]'
                      }`}
                    >
                      {privilegePrivateChef && (
                        <Check className="w-3.5 h-3.5 text-[#D4AF37] stroke-[3]" />
                      )}
                    </div>
                    <span className="text-xs text-[#1A202C] font-medium">
                      Estate Private Chef dining & personalized Ceylon arrack pairing
                    </span>
                  </label>

                  <label className="flex items-center gap-3 p-2.5 rounded-lg bg-[#F8F5EE] border border-[#D4AF37]/25 cursor-pointer hover:border-[#D4AF37]">
                    <div
                      onClick={() => setPrivilegeHelicopter(!privilegeHelicopter)}
                      className={`w-5 h-5 rounded flex items-center justify-center transition-colors border ${
                        privilegeHelicopter
                          ? 'bg-[#0F382A] border-[#D4AF37]'
                          : 'bg-[#FDFBF7] border-[#717974]'
                      }`}
                    >
                      {privilegeHelicopter && (
                        <Check className="w-3.5 h-3.5 text-[#D4AF37] stroke-[3]" />
                      )}
                    </div>
                    <span className="text-xs text-[#1A202C] font-medium">
                      Helicopter or Floatplane scenic inter-estate transfer upgrade
                    </span>
                  </label>
                </div>
              </div>

              {/* Special Notes */}
              <div>
                <label className="block text-xs font-semibold text-[#1A202C] mb-1.5 uppercase tracking-wider">
                  Special Wishes or Dietary Preferences
                </label>
                <textarea
                  rows={3}
                  value={specialRequests}
                  onChange={(e) => setSpecialRequests(e.target.value)}
                  placeholder="e.g. Inquiring about private vintage observation rail charter, gluten-free estate dining, anniversary floral arrangements..."
                  className="w-full bg-[#FDFBF7] border border-[#1A202C]/15 rounded-lg py-2.5 px-3.5 text-sm text-[#1A202C] focus:border-[#0F382A] focus:ring-2 focus:ring-[#D4AF37]/30 transition-all focus:outline-none placeholder:text-[#717974]/60 resize-none"
                />
              </div>

              {/* Guarantee info */}
              <div className="flex items-center gap-2 text-xs text-[#414844] pt-2">
                <Shield className="w-4 h-4 text-[#10B981] shrink-0" />
                <span>
                  Bespoke journeys are protected under Popular Ceylon Heritage Trust guarantees.
                </span>
              </div>

              {/* Submit CTA */}
              <div className="pt-4 flex items-center justify-end gap-3 border-t border-[#D4AF37]/20">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-3 rounded-lg text-sm font-semibold text-[#414844] hover:text-[#0F382A] hover:bg-[#F8F5EE] transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-7 py-3 rounded-lg bg-[#0F382A] text-[#FDFBF7] text-sm font-semibold hover:bg-[#144234] hover:border hover:border-[#D4AF37] transition-all cursor-pointer shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF37]"
                >
                  Dispatch Private Inquiry
                </button>
              </div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
