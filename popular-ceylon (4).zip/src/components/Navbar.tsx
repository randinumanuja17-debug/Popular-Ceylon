import React from 'react';
import { ScreenType } from '../types';

interface NavbarProps {
  currentScreen: ScreenType;
  onSelectScreen: (screen: ScreenType) => void;
  onOpenBooking: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentScreen,
  onSelectScreen,
  onOpenBooking,
}) => {
  const navItems: { id: ScreenType; label: string }[] = [
    { id: 'expeditions', label: 'Expeditions' },
    { id: 'destinations', label: 'Destinations' },
    { id: 'estates', label: 'Estates & Sanctuaries' },
    { id: 'bespoke', label: 'Bespoke Journey' },
    { id: 'journal', label: 'Ceylon Journal' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#FDFBF7]/95 backdrop-blur-md border-b border-[#D4AF37]/20 transition-all duration-200">
      <div className="max-w-[1440px] mx-auto px-6 md:px-12 lg:px-16 h-20 flex items-center justify-between">
        {/* Zone 1: Brand Wordmark (Single text element in Playfair Display serif) */}
        <button
          onClick={() => onSelectScreen('expeditions')}
          className="text-left group cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F382A]"
        >
          <span className="font-serif text-2xl md:text-3xl font-semibold tracking-tight text-[#0F382A] group-hover:text-[#184c3b] transition-colors">
            Popular Ceylon
          </span>
        </button>

        {/* Zone 2: Navigation Links (Clean text with subtle underline hover, single line) */}
        <nav className="hidden lg:flex items-center gap-8 text-[15px] font-medium text-[#1A202C]">
          {navItems.map((item) => {
            const isActive = currentScreen === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectScreen(item.id)}
                className={`relative py-2 transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AF37] ${
                  isActive
                    ? 'text-[#0F382A] font-semibold'
                    : 'text-[#414844] hover:text-[#0F382A]'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#D4AF37] rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Action (Deep Jungle Green with gilded touch) */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenBooking}
            className="px-6 py-2.5 rounded-lg bg-[#0F382A] text-[#FDFBF7] text-sm font-semibold tracking-wide hover:bg-[#144234] hover:border hover:border-[#D4AF37] transition-all duration-200 shadow-sm cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF37]"
          >
            Curate Journey
          </button>

          {/* Mobile view selector dropdown for small screens */}
          <div className="lg:hidden">
            <select
              value={currentScreen}
              onChange={(e) => onSelectScreen(e.target.value as ScreenType)}
              className="bg-[#F8F5EE] border border-[#D4AF37]/30 text-[#0F382A] text-xs font-semibold py-2 px-2.5 rounded-md focus:outline-none focus:ring-1 focus:ring-[#0F382A]"
              aria-label="Navigate screens"
            >
              {navItems.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </header>
  );
};
