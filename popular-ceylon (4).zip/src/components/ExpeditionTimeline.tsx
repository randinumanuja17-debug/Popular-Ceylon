import React from 'react';
import { ItineraryDay } from '../types';
import { Train, BedDouble, Compass, ShieldCheck } from 'lucide-react';

interface ExpeditionTimelineProps {
  days: ItineraryDay[];
  activeDay: number;
  onSelectDay: (day: number) => void;
}

export const ExpeditionTimeline: React.FC<ExpeditionTimelineProps> = ({
  days,
  activeDay,
  onSelectDay,
}) => {
  return (
    <div className="relative pl-6 md:pl-10 space-y-8">
      {/* Continuous 2px Golden Sand Route Line */}
      <div
        className="absolute left-[13px] md:left-[21px] top-6 bottom-8 w-[2px] bg-gradient-to-b from-[#D4AF37] via-[#D4AF37]/60 to-[#10B981]/80 z-0"
        aria-hidden="true"
      />

      {days.map((day) => {
        const isActive = activeDay === day.day;

        return (
          <div
            key={day.day}
            id={`day-${day.day}`}
            className="relative z-10 scroll-mt-28"
          >
            {/* Emerald Waypoint Dot with Outer Ring */}
            <div
              className={`absolute -left-[27px] md:-left-[35px] top-7 w-7 h-7 rounded-full flex items-center justify-center transition-all duration-300 ${
                isActive
                  ? 'bg-[#0F382A] ring-4 ring-[#D4AF37]/50 shadow-md scale-110'
                  : 'bg-[#FDFBF7] border-2 border-[#D4AF37] hover:scale-105'
              }`}
            >
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  isActive ? 'bg-[#10B981]' : 'bg-[#0F382A]'
                }`}
              />
            </div>

            {/* Itinerary Timeline Card Container */}
            <div
              onClick={() => onSelectDay(day.day)}
              className={`bg-[#F8F5EE] border rounded-2xl p-6 md:p-8 transition-all duration-300 cursor-pointer shadow-ceylon hover:shadow-ceylon-lg ${
                isActive
                  ? 'border-[#D4AF37] ring-1 ring-[#D4AF37]/40 bg-[#FAF7F0]'
                  : 'border-[#D4AF37]/25 hover:border-[#D4AF37]/60'
              }`}
            >
              {/* Header row: Day count kicker, region, and altitude metadata */}
              <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                <div className="flex items-center gap-2.5 text-xs text-[#414844]">
                  <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-[#D4AF37]">
                    Day 0{day.day}
                  </span>
                  <span aria-hidden="true" className="text-[#D4AF37]">·</span>
                  <span className="font-medium text-[#0F382A]">{day.region}</span>
                  <span aria-hidden="true" className="text-[#D4AF37]">·</span>
                  <span className="font-mono tabular-nums text-[#717974]">{day.elevationMeters}m altitude</span>
                </div>

                <div className="flex items-center gap-2">
                  {day.hasTrainCrossing && (
                    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#735c00] bg-[#fed65b]/25 border border-[#D4AF37]/40 px-2.5 py-1 rounded-md">
                      <Train className="w-3.5 h-3.5 text-[#735c00]" />
                      Scenic Rail Passage
                    </span>
                  )}
                  <span className="text-xs text-[#717974] italic">
                    {day.travelPace} Pace
                  </span>
                </div>
              </div>

              {/* Title */}
              <h3 className="font-serif text-2xl md:text-[26px] font-semibold text-[#0F382A] mb-3 leading-snug">
                {day.title}
              </h3>

              {/* Train Crossing Details if applicable */}
              {day.trainDetails && (
                <div className="mb-4 p-3 rounded-lg bg-[#FAF7F0] border border-[#D4AF37]/30 flex items-center gap-3 text-xs text-[#414844]">
                  <Train className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <span className="font-medium">
                    Heritage Rail Segment:{' '}
                    <strong className="text-[#0F382A]">{day.trainDetails}</strong>
                  </span>
                </div>
              )}

              {/* Summary narrative */}
              <p className="text-[15px] leading-relaxed text-[#414844] mb-6">
                {day.summary}
              </p>

              {/* Experience Highlights with Golden Diamond Glyphs */}
              <div className="mb-6">
                <h4 className="text-xs font-semibold uppercase tracking-[0.12em] text-[#0F382A] mb-3">
                  Curated Island Encounters
                </h4>
                <ul className="space-y-2 text-sm text-[#1A202C]">
                  {day.highlights.map((h, i) => (
                    <li key={i} className="flex items-start gap-2.5 leading-relaxed">
                      <span className="text-[#D4AF37] select-none text-xs mt-1 shrink-0">✦</span>
                      <span>{h}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Overnight Heritage Estate Lodge Box */}
              <div className="pt-5 border-t border-[#D4AF37]/20 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-lg overflow-hidden shrink-0 border border-[#D4AF37]/30 bg-[#e8eeff]">
                    <img
                      src={day.lodgingImage}
                      alt={day.lodgingName}
                      className="w-full h-full object-cover"
                      loading="lazy"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div>
                    <span className="text-[11px] font-semibold uppercase tracking-[0.1em] text-[#717974] block">
                      Overnight Sanctuary
                    </span>
                    <span className="font-serif text-base font-semibold text-[#0F382A] block">
                      {day.lodgingName}
                    </span>
                    <span className="text-xs text-[#414844]">
                      {day.lodgingType}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs text-[#0F382A] font-medium bg-[#FDFBF7] px-3 py-1.5 rounded-md border border-[#D4AF37]/30 self-start sm:self-auto">
                  <BedDouble className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>Private Butler & Full Board</span>
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
