/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ScreenType, Expedition, Destination, HeritageEstate } from './types';
import { Navbar } from './components/Navbar';
import { ExpeditionsScreen } from './components/screens/ExpeditionsScreen';
import { DestinationsScreen } from './components/screens/DestinationsScreen';
import { EstatesScreen } from './components/screens/EstatesScreen';
import { BespokeBuilderScreen } from './components/screens/BespokeBuilderScreen';
import { JournalScreen } from './components/screens/JournalScreen';
import { BookingModal } from './components/BookingModal';
import { Footer } from './components/Footer';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('expeditions');
  const [isBookingModalOpen, setIsBookingModalOpen] = useState<boolean>(false);
  const [preselectedExpedition, setPreselectedExpedition] = useState<Expedition | undefined>(undefined);
  const [preselectedCustomTitle, setPreselectedCustomTitle] = useState<string>('');
  const [bespokeDestinationFocus, setBespokeDestinationFocus] = useState<string>('');

  const handleSelectScreen = (screen: ScreenType) => {
    setCurrentScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenBookingGeneral = () => {
    setPreselectedExpedition(undefined);
    setPreselectedCustomTitle('The Tea Country Highland Passage');
    setIsBookingModalOpen(true);
  };

  const handleOpenBookingWithExpedition = (expedition: Expedition) => {
    setPreselectedExpedition(expedition);
    setPreselectedCustomTitle(expedition.title);
    setIsBookingModalOpen(true);
  };

  const handleOpenBookingForEstate = (estate: HeritageEstate) => {
    setPreselectedExpedition(undefined);
    setPreselectedCustomTitle(`Sanctuary Stay: ${estate.name}`);
    setIsBookingModalOpen(true);
  };

  const handleSelectDestinationForItinerary = (destination: Destination) => {
    setBespokeDestinationFocus(destination.name);
    setCurrentScreen('bespoke');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenBookingWithCustomPlan = (customSummary: string) => {
    setPreselectedExpedition(undefined);
    setPreselectedCustomTitle(customSummary);
    setIsBookingModalOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FDFBF7] text-[#1A202C]">
      {/* 1-Row 3-Zone Top Navigation Bar */}
      <Navbar
        currentScreen={currentScreen}
        onSelectScreen={handleSelectScreen}
        onOpenBooking={handleOpenBookingGeneral}
      />

      {/* Main View Area */}
      <main className="flex-1">
        {currentScreen === 'expeditions' && (
          <ExpeditionsScreen
            onOpenBookingWithExpedition={handleOpenBookingWithExpedition}
            onNavigateToBespoke={() => handleSelectScreen('bespoke')}
          />
        )}

        {currentScreen === 'destinations' && (
          <DestinationsScreen
            onSelectDestinationForItinerary={handleSelectDestinationForItinerary}
            onOpenBooking={handleOpenBookingGeneral}
          />
        )}

        {currentScreen === 'estates' && (
          <EstatesScreen
            onOpenBookingForEstate={handleOpenBookingForEstate}
          />
        )}

        {currentScreen === 'bespoke' && (
          <BespokeBuilderScreen
            onOpenBookingWithCustomPlan={handleOpenBookingWithCustomPlan}
            initialDestinationName={bespokeDestinationFocus}
          />
        )}

        {currentScreen === 'journal' && (
          <JournalScreen
            onExploreExpedition={() => handleSelectScreen('expeditions')}
          />
        )}
      </main>

      {/* Luxury Booking & Inquiry Capsule (Tier 2 Floating Modal) */}
      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        expedition={preselectedExpedition}
        preselectedExpeditionTitle={preselectedCustomTitle}
      />

      {/* Editorial Footer */}
      <Footer
        onSelectScreen={handleSelectScreen}
        onOpenBooking={handleOpenBookingGeneral}
      />
    </div>
  );
}
