import { Expedition, Destination, HeritageEstate, JournalArticle } from '../types';

export const EXPEDITIONS: Expedition[] = [
  {
    id: 'highland-tea-passage',
    title: 'The Tea Country Highland Passage',
    subtitle: 'From Mist-Veiled Valleys to the Nine Arches Viaduct',
    tagline: 'An eight-day reverie across Ceylon’s highest emerald peaks, historic colonial planter bungalows, and private observation rail carriages.',
    durationDays: 8,
    season: 'December through April',
    startingPriceUsd: 5800,
    startingPriceGbp: 4600,
    heroImage: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1600&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1586861635167-e5223aadc9fe?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1566296314736-6eaac1ca0cb9?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=80'
    ],
    routeSummary: 'Colombo → Bogawantalawa Valley → Hatton → Nuwara Eliya → Ella',
    elevationRange: '15m to 1,890m',
    travelStyle: 'Colonial Heritage & Sensory Botany',
    maxGuests: 6,
    overview: 'Ascend from the humid coastal breeze into the cool, eucalyptus-scented high mountains where British governors and Scottish planters carved the world’s most celebrated tea empires. Stay in restored colonial bungalows with private butlers, sip single-estate Broken Orange Pekoe at dawn, and traverse the iconic Nine Arches viaduct aboard a restored wooden observation carriage.',
    includedPrivileges: [
      'Private Master Tea Sommelier guided tasting at 1,500 meters',
      'First-class reserved vintage observation carriage on the Viceroy rail passage',
      'Personal resident butler across all heritage bungalows',
      'Private helicopter luggage forwarding between highland estates',
      'Sunrise breakfast overlooking Castlereagh Reservoir'
    ],
    days: [
      {
        day: 1,
        title: 'Arrival into the Emerald Gate',
        region: 'Colombo & Negombo Lagoon',
        elevationMeters: 15,
        terrainType: 'coastal',
        lodgingName: 'The Wallawwa Heritage Manor',
        lodgingType: '18th-century Colonial Country House',
        lodgingImage: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
        summary: 'Touch down at Bandaranaike International. Private VIP airside greeting and private transfer to a 200-year-old manor enveloped by tropical jackfruit trees.',
        highlights: [
          'VIP tarmac immigration escort & chilled Ceylon king coconut service',
          'Evening garden cocktail featuring artisanal arrack and lemongrass infusions',
          'Briefing with expedition leader on the highland passage ahead'
        ],
        travelPace: 'Gentle'
      },
      {
        day: 2,
        title: 'Ascent to Bogawantalawa & The Golden Valley',
        region: 'Bogawantalawa Valley',
        elevationMeters: 1220,
        terrainType: 'highland',
        lodgingName: 'Ceylon Tea Trails — Castlereagh Bungalow',
        lodgingType: 'Relais & Châteaux Planter Bungalow',
        lodgingImage: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=800&q=80',
        summary: 'Wind up through winding hairpin roads as rubber plantations yield to manicured tea terraces. Arrive at Castlereagh on the emerald reservoir shoreline.',
        highlights: [
          'Scenic drive through roaring Devon and St. Clair cascading waterfalls',
          'Traditional English afternoon cream tea on the manicured croquet lawn',
          'Four-course woodfire dinner paired with highland single malt selections'
        ],
        travelPace: 'Immersive'
      },
      {
        day: 3,
        title: 'The Planter’s Dawn & Single-Estate Botany',
        region: 'Castlereagh & Norwood',
        elevationMeters: 1350,
        terrainType: 'highland',
        lodgingName: 'Ceylon Tea Trails — Norwood Bungalow',
        lodgingType: 'Heritage Tea Estate Suite',
        lodgingImage: 'https://images.unsplash.com/photo-1566296314736-6eaac1ca0cb9?auto=format&fit=crop&w=800&q=80',
        summary: 'Wake to the gentle ring of the morning bed-tea bell. Join the resident tea planter through 100-year-old bushes and witness the orthodox tea withering process.',
        highlights: [
          'Hands-on two-leaves-and-a-bud plucking alongside generational tea pluckers',
          'Private factory tour inspecting 1920s British brass rollers and sorting sieves',
          'Curated cupping session tasting Silver Tips, Flowery Orange Pekoe, and Dust 1'
        ],
        travelPace: 'Active'
      },
      {
        day: 4,
        title: 'Little England & The Pedro Highland Estate',
        region: 'Nuwara Eliya',
        elevationMeters: 1890,
        terrainType: 'highland',
        lodgingName: 'The Hill Club & Governor’s Suite',
        lodgingType: '1876 Gentleman’s Colonial Club',
        lodgingImage: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=800&q=80',
        summary: 'Climb toward Ceylon’s highest plateau. Cool mountain mist descends over mock-Tudor gables, rose gardens, and the highest tea factory in the Commonwealth.',
        highlights: [
          'Stroll around Lake Gregory and colonial post office architectural landmarks',
          'Visit to the misty slopes of Pidurutalagala mountain reserve',
          'Formal silver-service black-tie optional dinner in the historic billiard lounge'
        ],
        travelPace: 'Gentle'
      },
      {
        day: 5,
        title: 'The Great Highland Train & Nine Arches Bridge',
        region: 'Nuwara Eliya to Ella Pass',
        elevationMeters: 1650,
        terrainType: 'highland',
        hasTrainCrossing: true,
        trainDetails: 'Viceroy Vintage Rail Car · Nanu Oya to Demodara Loop',
        lodgingName: 'Nine Skies Bungalow',
        lodgingType: 'Highland Hilltop Sanctuary',
        lodgingImage: 'https://images.unsplash.com/photo-1586861635167-e5223aadc9fe?auto=format&fit=crop&w=800&q=80',
        summary: 'Board the historic blue highland train at Nanu Oya. Wind past eucalyptus forests and plunge through cloud banks toward the famed Nine Arches viaduct.',
        highlights: [
          'Open observation car windows framing sheer cliff drops and cascading falls',
          'Private champagne toast as the train curves over the Demodara Spiral Loop',
          'Afternoon sunset hike to Little Adam’s Peak offering panoramic valley views'
        ],
        travelPace: 'Immersive'
      },
      {
        day: 6,
        title: 'Ravana Ravine & Ella Gap Cloud Canopy',
        region: 'Ella Gap',
        elevationMeters: 1041,
        terrainType: 'highland',
        lodgingName: 'Nine Skies Bungalow',
        lodgingType: 'Highland Hilltop Sanctuary',
        lodgingImage: 'https://images.unsplash.com/photo-1586861635167-e5223aadc9fe?auto=format&fit=crop&w=800&q=80',
        summary: 'Wake above a sea of white cloud spilling through Ella Gap. Explore the ancient Ravana caves steeped in Ramayana mythology.',
        highlights: [
          'Dawn yoga on the cliff-edge wooden deck overlooking Southern plains',
          'Private wild spice garden tour featuring native Ceylon true cinnamon (Cinnamomum verum)',
          'Evening gin & tonic pairing with local wild botanicals by the outdoor fireplace'
        ],
        travelPace: 'Immersive'
      },
      {
        day: 7,
        title: 'The Southern Descent to Wellawaya Foothills',
        region: 'Wellawaya',
        elevationMeters: 420,
        terrainType: 'cultural',
        lodgingName: 'Jetwing Kaduruketha',
        lodgingType: 'Paddy Field Agro-Luxury Eco Lodge',
        lodgingImage: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80',
        summary: 'Descend through changing vegetation zones, watching highland mist give way to dry zone peacocks, giant kumbuk trees, and golden paddy fields.',
        highlights: [
          'Private visit to Buduruwagala: 10th-century colossal rock-cut Buddha sculptures',
          'Bicycle excursion through heirloom paddy canals at golden hour',
          'Traditional open-air kamatha feast cooked in clay earthenware pots'
        ],
        travelPace: 'Gentle'
      },
      {
        day: 8,
        title: 'Homeward Passage via Colombo Shoreline',
        region: 'Colombo Coast',
        elevationMeters: 10,
        terrainType: 'coastal',
        lodgingName: 'Galle Face Hotel (Departure Lounge)',
        lodgingType: '1864 Grand Dame on the Indian Ocean',
        lodgingImage: 'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?auto=format&fit=crop&w=800&q=80',
        summary: 'Scenic highway return or floatplane hop to Colombo. Afternoon tea on the chequered ocean terrace before airport transfer.',
        highlights: [
          'Sunset bagpiper ceremony on the Galle Face Green sea ramparts',
          'Private packing service with wooden tea caddies stamped with your seal',
          'VIP direct tarmac transfer to international departure gates'
        ],
        travelPace: 'Gentle'
      }
    ]
  },
  {
    id: 'royal-kingdoms-wild-leopard',
    title: 'Royal Kingdoms & Leopard Wilderness',
    subtitle: 'From the Sky Fortress of Sigiriya to the Coastal Dunes of Yala',
    tagline: 'Ten days uniting two millennia of ancient hydraulic civilisations with the highest density of wild leopards on Earth.',
    durationDays: 10,
    season: 'Year-round (Best Nov - Aug)',
    startingPriceUsd: 7200,
    startingPriceGbp: 5750,
    heroImage: 'https://images.unsplash.com/photo-1588598198321-9735fd52455b?auto=format&fit=crop&w=1600&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1561731216-c3a4d99437d5?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1589182373726-e4f658ab50f0?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?auto=format&fit=crop&w=1200&q=80'
    ],
    routeSummary: 'Colombo → Sigiriya → Polonnaruwa → Kandy → Yala National Park',
    elevationRange: '30m to 500m',
    travelStyle: 'Archaeological Splendour & Apex Wildlife',
    maxGuests: 4,
    overview: 'Unearth the marvels of the Cultural Triangle: 5th-century pleasure gardens carved into sheer monoliths, sacred tooth relics, and ancient reservoirs where wild elephants gather in their hundreds. Then journey south to Yala’s thorny scrublands where the Panthera pardus kotiya reigns supreme.',
    includedPrivileges: [
      'Private sunrise opening of Sigiriya Rock Fortress before general public gates',
      'Customized open-top Land Cruiser with Senior Wildlife Warden naturalist',
      'Private blessings ceremony at the Temple of the Sacred Tooth in Kandy',
      'Canvas cocktail lounge set up at sunset on Yala’s ocean dunes',
      'Full-board dining with personal estate chef'
    ],
    days: [
      {
        day: 1,
        title: 'Arrival & Journey to the Cultural Heartland',
        region: 'Sigiriya & Dambulla',
        elevationMeters: 180,
        terrainType: 'cultural',
        lodgingName: 'Water Garden Sigiriya',
        lodgingType: 'Water Villa Pavilion Complex',
        lodgingImage: 'https://images.unsplash.com/photo-1588598198321-9735fd52455b?auto=format&fit=crop&w=800&q=80',
        summary: 'Travel into the dry zone plains where sudden granite monoliths thrust violently through the forest canopy.',
        highlights: [
          'Scenic arrival cocktail overlooking the reflections of Lion Rock',
          'Orientation on ancient Sri Lankan irrigation engineering'
        ],
        travelPace: 'Gentle'
      },
      {
        day: 2,
        title: 'The Lion Rock Citadel & Mirror Wall Frescoes',
        region: 'Sigiriya Citadel',
        elevationMeters: 349,
        terrainType: 'cultural',
        lodgingName: 'Water Garden Sigiriya',
        lodgingType: 'Water Villa Pavilion Complex',
        lodgingImage: 'https://images.unsplash.com/photo-1588598198321-9735fd52455b?auto=format&fit=crop&w=800&q=80',
        summary: 'Ascend King Kasyapa’s 5th-century mountain palace at first light. Marvel at world-renowned celestial maiden frescoes.',
        highlights: [
          'Pre-dawn ascent bypassing all tourist crowds with private archaeologist guide',
          'Examination of ancient graffiti poetry on the porcelain-polished Mirror Wall',
          'Champagne brunch beside the lower water gardens upon descent'
        ],
        travelPace: 'Active'
      },
      {
        day: 3,
        title: 'The Medieval Capital of Polonnaruwa',
        region: 'Polonnaruwa Relics',
        elevationMeters: 60,
        terrainType: 'cultural',
        lodgingName: 'Water Garden Sigiriya',
        lodgingType: 'Water Villa Pavilion Complex',
        lodgingImage: 'https://images.unsplash.com/photo-1588598198321-9735fd52455b?auto=format&fit=crop&w=800&q=80',
        summary: 'Explore 12th-century stupas, royal bath pavilions, and the magnificent rock-hewn Gal Vihara Buddhas by private vintage bicycles.',
        highlights: [
          'Gal Vihara: colossal monolithic granite statues in meditative and reclining repose',
          'Private boat cruise across Parakrama Samudra sea reservoir at sunset',
          'Spotting wild toque macaques studied by the Smithsonian Institute'
        ],
        travelPace: 'Immersive'
      },
      {
        day: 4,
        title: 'Cave Temples of Dambulla & Spice Hills',
        region: 'Dambulla to Kandy',
        elevationMeters: 500,
        terrainType: 'cultural',
        lodgingName: 'The Kandy House',
        lodgingType: '1804 Aristocratic Manor House',
        lodgingImage: 'https://images.unsplash.com/photo-1589182373726-e4f658ab50f0?auto=format&fit=crop&w=800&q=80',
        summary: 'Climb to the five sacred painted caves of Dambulla housing 150 Buddha statues, followed by the ascent to Kandy.',
        highlights: [
          'Gold-leaf cave ceilings and intact mural art dating to 1st century BCE',
          'Private evening witnessing of the sacred drumming ceremony (Tevava) at the Temple of the Tooth'
        ],
        travelPace: 'Immersive'
      },
      {
        day: 5,
        title: 'The Sacred Relic & Knuckles Mist Foothills',
        region: 'Kandy Kingdom',
        elevationMeters: 550,
        terrainType: 'cultural',
        lodgingName: 'The Kandy House',
        lodgingType: '1804 Aristocratic Manor House',
        lodgingImage: 'https://images.unsplash.com/photo-1589182373726-e4f658ab50f0?auto=format&fit=crop&w=800&q=80',
        summary: 'Wander through the Royal Botanical Gardens of Peradeniya, home to giant Javan fig trees and orchid houses curated for royalty.',
        highlights: [
          'Curator-led walk under the Royal Palm avenues and double coconut palms',
          'Private audience with a traditional Kandyan dance master'
        ],
        travelPace: 'Gentle'
      },
      {
        day: 6,
        title: 'Southward Journey to the Wild Frontier',
        region: 'Yala Borderland',
        elevationMeters: 45,
        terrainType: 'wildlife',
        lodgingName: 'Wild Coast Tented Lodge',
        lodgingType: 'Luxury Cocoon Suite on the Beach',
        lodgingImage: 'https://images.unsplash.com/photo-1561731216-c3a4d99437d5?auto=format&fit=crop&w=800&q=80',
        summary: 'Arrive at the spectacular convergence of golden sand dunes, roaring Indian Ocean surf, and dense scrub wilderness.',
        highlights: [
          'Check-in to iconic arched canvas cocoons inspired by natural rock boulders',
          'Sunset cocktails on the rugged sea cliffs as white-bellied sea eagles soar'
        ],
        travelPace: 'Gentle'
      },
      {
        day: 7,
        title: 'In Search of the Apex Predator: Yala Block 1',
        region: 'Yala National Park',
        elevationMeters: 30,
        terrainType: 'wildlife',
        lodgingName: 'Wild Coast Tented Lodge',
        lodgingType: 'Luxury Cocoon Suite on the Beach',
        lodgingImage: 'https://images.unsplash.com/photo-1561731216-c3a4d99437d5?auto=format&fit=crop&w=800&q=80',
        summary: 'Enter the park gates at 05:45 AM before light breaks. Track fresh pugmarks across sand roads and listen for spotted deer alarm barks.',
        highlights: [
          'Tracking Sri Lankan leopards (Panthera pardus kotiya) sunning on giant gneiss boulders',
          'Close encounters with wild Asian elephant herds, sloth bears, and mugger crocodiles',
          'Bush breakfast served in a secluded dry riverbed'
        ],
        travelPace: 'Active'
      },
      {
        day: 8,
        title: 'The Untamed Wilderness of Lunugamvehera',
        region: 'Lunugamvehera & Bundala',
        elevationMeters: 40,
        terrainType: 'wildlife',
        lodgingName: 'Wild Coast Tented Lodge',
        lodgingType: 'Luxury Cocoon Suite on the Beach',
        lodgingImage: 'https://images.unsplash.com/photo-1561731216-c3a4d99437d5?auto=format&fit=crop&w=800&q=80',
        summary: 'Explore lesser-travelled elephant migration corridors and UNESCO Ramsar wetlands teeming with thousands of migratory flamingos.',
        highlights: [
          'Birding expedition through Bundala salt lagoons: painted storks, pelicans, and bee-eaters',
          'Stargazing astronomy session under unpolluted Southern skies with camp naturalist'
        ],
        travelPace: 'Immersive'
      },
      {
        day: 9,
        title: 'Coastal Passage to the Galle Ramparts',
        region: 'Southern Coast to Galle',
        elevationMeters: 10,
        terrainType: 'coastal',
        lodgingName: 'Amangalla',
        lodgingType: 'Historic Dutch Colonial Sanctuary',
        lodgingImage: 'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?auto=format&fit=crop&w=800&q=80',
        summary: 'Follow the palm-fringed southern coastline to the UNESCO World Heritage fortress town of Galle Fort.',
        highlights: [
          'Passing traditional stilt fishermen of Weligama',
          'Evening stroll along the massive granite sea walls built by the Dutch in 1663'
        ],
        travelPace: 'Gentle'
      },
      {
        day: 10,
        title: 'Galle Farewell & Homeward Departure',
        region: 'Galle Fort & Colombo',
        elevationMeters: 5,
        terrainType: 'coastal',
        lodgingName: 'Amangalla',
        lodgingType: 'Historic Dutch Colonial Sanctuary',
        lodgingImage: 'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?auto=format&fit=crop&w=800&q=80',
        summary: 'Final antique shopping, private gemologist consultation for Ceylon blue sapphires, and departure transfer.',
        highlights: [
          'Private heritage tour with Galle Fort historian',
          'Express transfer via the Southern Expressway to Bandaranaike International Airport'
        ],
        travelPace: 'Gentle'
      }
    ]
  },
  {
    id: 'southern-cinnamon-coast',
    title: 'Southern Galle Serenade & Cinnamon Coast',
    subtitle: 'From Geoffrey Bawa’s Country Estate to Whales of Mirissa',
    tagline: 'Seven days of architectural tropical modernism, oceanfront sanctuary, and blue sapphire culture along the golden southern shore.',
    durationDays: 7,
    season: 'October through April',
    startingPriceUsd: 4900,
    startingPriceGbp: 3900,
    heroImage: 'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?auto=format&fit=crop&w=1600&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1589182373726-e4f658ab50f0?auto=format&fit=crop&w=1200&q=80'
    ],
    routeSummary: 'Bentota → Galle Fort → Weligama → Tangalle',
    elevationRange: '0m to 85m',
    travelStyle: 'Tropical Modernism & Ocean Serenity',
    maxGuests: 6,
    overview: 'Bask in the architectural genius of Geoffrey Bawa at Lunuganga, sleep inside the 400-year-old bastions of Galle Fort, and sail out on a private catamaran to encounter majestic blue whales in deep pelagic trenches off Mirissa.',
    includedPrivileges: [
      'Private boat charter for blue whale spotting with marine biologist',
      'Private dinner inside Geoffrey Bawa’s glass house pavilion at Lunuganga',
      'VIP access to closed Dutch archives and secret underground cisterns of Galle Fort',
      'Daily holistic Ayurvedic massage at The Baths'
    ],
    days: [
      {
        day: 1,
        title: 'Lunuganga: The Architect’s Private Garden',
        region: 'Bentota Lake',
        elevationMeters: 12,
        terrainType: 'coastal',
        lodgingName: 'Lunuganga Country Estate',
        lodgingType: 'Geoffrey Bawa Estate',
        lodgingImage: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
        summary: 'Enter the living masterpiece created over 50 years by Sri Lanka’s greatest architect, overlooking Dedduwa lake.',
        highlights: [
          'Architectural curator tour of Italianate terraces, Roman busts, and water vistas',
          'Private sundowners at the Broadwalk jetty'
        ],
        travelPace: 'Gentle'
      },
      {
        day: 2,
        title: 'The Cinnamon Islands & River Safaris',
        region: 'Madu Ganga & Balapitiya',
        elevationMeters: 5,
        terrainType: 'coastal',
        lodgingName: 'Lunuganga Country Estate',
        lodgingType: 'Geoffrey Bawa Estate',
        lodgingImage: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
        summary: 'Cruise through 64 mangrove islands. Learn how pure Ceylon cinnamon bark is peeled by master craftsmen.',
        highlights: [
          'Mangrove kayak exploration through cathedral-like root tunnels',
          'Demonstration of quill rolling by three generations of cinnamon farmers'
        ],
        travelPace: 'Immersive'
      },
      {
        day: 3,
        title: 'Entering the Living Dutch Bastion',
        region: 'Galle Fort',
        elevationMeters: 8,
        terrainType: 'coastal',
        lodgingName: 'Amangalla',
        lodgingType: '17th-Century Colonial Sanctuary',
        lodgingImage: 'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?auto=format&fit=crop&w=800&q=80',
        summary: 'Transfer to Galle Fort, settling into polished jackwood floors, four-poster beds, and antique pettagama chests.',
        highlights: [
          'Traditional Ceylon high tea on the Grand Verandah with live classical strings',
          'Private gemological inspection of unheated Padparadscha sapphires'
        ],
        travelPace: 'Gentle'
      },
      {
        day: 4,
        title: 'Blue Whales of the Pelagic Deep',
        region: 'Mirissa Bay',
        elevationMeters: 0,
        terrainType: 'coastal',
        lodgingName: 'Amangalla',
        lodgingType: '17th-Century Colonial Sanctuary',
        lodgingImage: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80',
        summary: 'Board a sleek private twin-hull catamaran at dawn. Cruise into deep waters where the continental shelf drops thousands of fathoms.',
        highlights: [
          'Spotting Blue Whales (Balaenoptera musculus) and pods of spinner dolphins',
          'Gourmet onboard breakfast and champagne as the ocean awakens',
          'Swim stop at a protected coral lagoon with wild green sea turtles'
        ],
        travelPace: 'Active'
      },
      {
        day: 5,
        title: 'The Secret Tea & Cinnamon Terraces of Handunugoda',
        region: 'Koggala & Handunugoda',
        elevationMeters: 65,
        terrainType: 'cultural',
        lodgingName: 'Kahanda Kanda',
        lodgingType: 'Hilltop Plantation Villa',
        lodgingImage: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=800&q=80',
        summary: 'Visit the Virgin White Tea plantation, where tea leaves are harvested without human hands touching the bud.',
        highlights: [
          'Tasting the celestial Virgin White Tea served in fine bone china',
          'Cooking masterclass: Jaffna crab curry prepared with toasted coconut milk'
        ],
        travelPace: 'Immersive'
      },
      {
        day: 6,
        title: 'Crescent Bays & Ayurvedic Renewal',
        region: 'Tangalle Coast',
        elevationMeters: 4,
        terrainType: 'coastal',
        lodgingName: 'Amanwella',
        lodgingType: 'Minimalist Modern Ocean Suite',
        lodgingImage: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80',
        summary: 'Retreat to a crescent bay of golden sand and towering coconut palms. Indulge in tailored Ayurvedic rejuvenation.',
        highlights: [
          'Full-body herbal warm oil abhyanga and shirodhara treatment',
          'Private beach barbecue with fresh rock lobster under the Southern Cross'
        ],
        travelPace: 'Gentle'
      },
      {
        day: 7,
        title: 'The Ocean Farewell',
        region: 'Tangalle to Colombo',
        elevationMeters: 10,
        terrainType: 'coastal',
        lodgingName: 'Amanwella',
        lodgingType: 'Minimalist Modern Ocean Suite',
        lodgingImage: 'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?auto=format&fit=crop&w=800&q=80',
        summary: 'Final ocean swim at sunrise, private brunch on your terrace, and helicopter transfer directly to the departure terminal.',
        highlights: [
          'Helicopter scenic flight tracing the southern coastline back to Colombo',
          'Custom keepsake leather journal engraved with your journey coordinates'
        ],
        travelPace: 'Gentle'
      }
    ]
  }
];

export const DESTINATIONS: Destination[] = [
  {
    id: 'central-highlands',
    name: 'The Central Highlands & Tea Valleys',
    sinhalaName: 'මධ්‍යම කඳුකරය (Madyama Kandukara)',
    region: 'Central Highlands',
    elevation: '1,200m – 2,524m',
    climate: 'Cool Subtropical (14°C – 22°C), crisp morning mist',
    bestMonths: 'December – May',
    heroImage: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1200&q=80',
    summary: 'The misty amphitheatre of world-renowned Ceylon tea estates, dramatic gorges, and cascading mountain cataracts.',
    editorialInsight: 'When Scottish pioneers planted the first Camellia sinensis in the 1860s after coffee blight, they created a timeless microclimate landscape where log fires burn each night while orchids bloom outdoors.',
    highlights: [
      'Castlereagh & Maussakelle emerald mountain reservoirs',
      'The legendary Nine Arches Viaduct and Demodara rail loop',
      'World’s End sheer 880-meter drop at Horton Plains National Park',
      'Exclusive single-estate orthodox tea tastings at 1,500m'
    ],
    coordinates: { x: 52, y: 62 }
  },
  {
    id: 'cultural-triangle',
    name: 'The Cultural Triangle & Sigiriya',
    sinhalaName: 'සංස්කෘතික ත්‍රිකෝණය',
    region: 'Cultural Triangle',
    elevation: '80m – 350m',
    climate: 'Warm Dry Zone (26°C – 33°C), sunny and arid',
    bestMonths: 'Year-round (Best: January – September)',
    heroImage: 'https://images.unsplash.com/photo-1588598198321-9735fd52455b?auto=format&fit=crop&w=1200&q=80',
    summary: 'Ancient capitals of Buddhist civilization featuring monolithic sky fortresses, cave monasteries, and ingenious water gardens.',
    editorialInsight: 'Before Rome engineered aqueducts, ancient Sinhala hydraulic kings mastered low-gradient sluice gates (Bisokotuwa) that stored monsoon rains for centuries.',
    highlights: [
      'Sigiriya 5th-century Lion Rock fortress and fresco maidens',
      'Gal Vihara rock-cut Buddha sculptures of Polonnaruwa',
      'Golden Dambulla cave complex with 150 gold-leaf statues',
      'The Great Elephant Gathering at Minneriya National Park'
    ],
    coordinates: { x: 50, y: 38 }
  },
  {
    id: 'galle-coast',
    name: 'Galle Fort & The Cinnamon Coast',
    sinhalaName: 'ගාල්ල බලකොටුව (Galla Balakotuwa)',
    region: 'Western Galle Coast',
    elevation: '0m – 30m',
    climate: 'Warm Coastal (27°C – 31°C), gentle ocean zephyrs',
    bestMonths: 'November – April',
    heroImage: 'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?auto=format&fit=crop&w=1200&q=80',
    summary: 'Living 17th-century UNESCO maritime fort where European colonial bastions merge seamlessly with exotic spices, gems, and modernist tropical villas.',
    editorialInsight: 'Wandering Galle Fort is a journey through Portuguese coral stone, Dutch ramparts, and British colonial verandas, now housing world-class boutique sanctuaries and gem ateliers.',
    highlights: [
      'Rampart sunset walks overlooking the Indian Ocean cricket ground',
      'Geoffrey Bawa’s architectural country estate at Lunuganga',
      'Virgin White Tea plantations and true cinnamon harvesting',
      'Blue sapphire ateliers and private gemologist workshops'
    ],
    coordinates: { x: 38, y: 88 }
  },
  {
    id: 'yala-wild-south',
    name: 'Yala & Deep Southern Wilderness',
    sinhalaName: 'යාල ජාතික වනෝද්‍යානය',
    region: 'Deep South & Coast',
    elevation: '10m – 90m',
    climate: 'Semi-arid Savanna (28°C – 34°C)',
    bestMonths: 'February – July',
    heroImage: 'https://images.unsplash.com/photo-1561731216-c3a4d99437d5?auto=format&fit=crop&w=1200&q=80',
    summary: 'Rugged thorny wilderness bounded by roaring ocean dunes, home to the greatest concentration of leopards on earth.',
    editorialInsight: 'Unlike African leopards who must contend with lions and hyenas, the Sri Lankan leopard is the undisputed apex monarch of this ecosystem, stalking openly across sand tracks in broad daylight.',
    highlights: [
      'Apex leopard tracking in Yala Block 1 and Kumana sanctuary',
      'Pelagic blue whale encounters off Mirissa and Dondra Head',
      'Ramsar wetland birding at Bundala lagoons',
      'Coastal tented luxury lodges facing untouched wild beaches'
    ],
    coordinates: { x: 74, y: 82 }
  },
  {
    id: 'sacred-kandy',
    name: 'The Sacred Kingdom of Kandy',
    sinhalaName: 'මහනුවර (Mahanuwara)',
    region: 'Central Highlands',
    elevation: '500m – 600m',
    climate: 'Mild Hill Country (20°C – 28°C)',
    bestMonths: 'December – May',
    heroImage: 'https://images.unsplash.com/photo-1589182373726-e4f658ab50f0?auto=format&fit=crop&w=1200&q=80',
    summary: 'The last royal kingdom of Ceylon, nestled around a tranquil lake surrounded by misty cloud forest mountains.',
    editorialInsight: 'Kandy resisted foreign colonial rule for three centuries through fierce mountain guerrilla strategy before falling in 1815, preserving the pure spiritual soul of the island.',
    highlights: [
      'The Temple of the Sacred Tooth Relic (Sri Dalada Maligawa)',
      'Peradeniya Royal Botanical Gardens featuring 4,000 plant species',
      'Ancient drum-making and Kandyan dance masteries',
      'Foothill gateway to the untamed Knuckles Mountain Range'
    ],
    coordinates: { x: 48, y: 52 }
  }
];

export const HERITAGE_ESTATES: HeritageEstate[] = [
  {
    id: 'castlereagh-tea-trails',
    name: 'Ceylon Tea Trails — Castlereagh Bungalow',
    location: 'Bogawantalawa Valley, Hatton',
    category: 'Colonial Tea Planter',
    builtYear: '1925',
    architectOrFounder: 'British Planter G.H. Masefield',
    startingNightlyUsd: 1150,
    heroImage: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1000&q=80',
    description: 'Nestled in a wooded dell on the shores of Castlereagh Lake, this masterfully restored colonial bungalow features parquet floors, roaring fireplaces, clawfoot bathtubs, and emerald garden swimming pools.',
    signatureExperience: 'Morning tea served in your four-poster bed by your resident butler, followed by a private lakeside kayak expedition.',
    amenities: ['Dedicated Resident Butler', 'Heated Garden Swimming Pool', 'Clay Tennis Court', 'Private Lake Jetty', 'Woodfire Fireplace Lounge'],
    elevation: '1,220 meters'
  },
  {
    id: 'amangalla-galle',
    name: 'Amangalla Sanctuary',
    location: 'Inside Galle Fort UNESCO Ramparts',
    category: 'Colonial Tea Planter',
    builtYear: '1684 (New Oriental Hotel)',
    architectOrFounder: 'Dutch Commandeur of Galle',
    startingNightlyUsd: 1400,
    heroImage: 'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?auto=format&fit=crop&w=1000&q=80',
    description: 'A monument to colonial grace inside the 400-year-old fort. Polished jackwood floorboards, antique chandelier lighting, antique four-poster beds, and the legendary subterranean hydrotherapy Baths.',
    signatureExperience: 'Traditional Afternoon Cream Tea on the Grand Verandah serenaded by string quartet as fort life wanders by.',
    amenities: ['The Baths Hydrotherapy & Ayurvedic Spa', '21m Garden Swimming Pool', 'Library of Rare Ceylon Cartography', 'Jackwood Suite Living Rooms'],
    elevation: '8 meters'
  },
  {
    id: 'wild-coast-tented',
    name: 'Wild Coast Tented Lodge',
    location: 'Yala National Park Beachfront',
    category: 'Private Safari Lodge',
    builtYear: '2017',
    architectOrFounder: 'Nomadic Resorts Architecture',
    startingNightlyUsd: 1550,
    heroImage: 'https://images.unsplash.com/photo-1561731216-c3a4d99437d5?auto=format&fit=crop&w=1000&q=80',
    description: 'Spectacular arched canvas cocoon suites designed to mimic the natural boulders scattered across Yala. Where the wild jungle meets the ocean surf.',
    signatureExperience: 'Private dusk safari into restricted leopard zones followed by campfire arrack cocktails on the dunes.',
    amenities: ['Free-form Natural Salt Pool', 'Private Plunge Pools in Urchin Suites', 'Custom Safari Land Cruisers', 'Outdoor Bamboo Bar'],
    elevation: '15 meters'
  },
  {
    id: 'lunuganga-bawa-estate',
    name: 'Lunuganga Country Estate',
    location: 'Bentota Dedduwa Lake',
    category: 'Tropical Modernism',
    builtYear: '1948',
    architectOrFounder: 'Deshamanya Geoffrey Bawa',
    startingNightlyUsd: 850,
    heroImage: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1000&q=80',
    description: 'The personal country retreat of legendary architect Geoffrey Bawa. An idyllic, twenty-five-acre landscape experiment blending Italian renaissance garden design with lush tropical botany.',
    signatureExperience: 'Sunset dinner in the glass house pavilion with menus inspired by Bawa’s personal dinner party journals.',
    amenities: ['Geoffrey Bawa Suite & Original Sketches', 'Cinnamon Hill Vistas', 'Private Lake Boat Cruising', 'Sculpture Pavilions'],
    elevation: '12 meters'
  },
  {
    id: 'amanwella-tangalle',
    name: 'Amanwella Beachfront Haven',
    location: 'Tangalle Crescent Bay',
    category: 'Coastal Beachfront',
    builtYear: '2005',
    architectOrFounder: 'Kerry Hill Architects (Bawa Inspired)',
    startingNightlyUsd: 1300,
    heroImage: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1000&q=80',
    description: 'A contemporary tribute to tropical modernist design nestled in a grove of coconut palms along a pristine crescent beach in Tangalle.',
    signatureExperience: 'Dawn private yoga session facing the ocean breakers, followed by fresh passion fruit and king coconut on your terrace.',
    amenities: ['Private Courtyard Plunge Pools', '47m Multi-Tiered Infinity Pool', 'Private Beachfront Beach Club', 'Ayurvedic Treatment Suites'],
    elevation: '5 meters'
  },
  {
    id: 'kandy-house',
    name: 'The Kandy House Manor',
    location: 'Kiribatkumbura, Kandy Foothills',
    category: 'Tropical Modernism',
    builtYear: '1804',
    architectOrFounder: 'Chief Minister of the Kandyan Kingdom',
    startingNightlyUsd: 780,
    heroImage: 'https://images.unsplash.com/photo-1589182373726-e4f658ab50f0?auto=format&fit=crop&w=1000&q=80',
    description: 'An aristocratic Walauwa (manor house) built by the last king’s chief minister. Exquisitely redesigned with infinity pool overlooking tropical paddy fields.',
    signatureExperience: 'Eight-course Kandyan royal spice curry banquet served under the ancient frangipani trees at candlelight.',
    amenities: ['Paddy View Infinity Pool', 'Heritage Butterfly Gardens', 'Master Ayurvedic Therapist', 'Historic Library Lounge'],
    elevation: '520 meters'
  }
];

export const JOURNAL_ARTICLES: JournalArticle[] = [
  {
    id: 'tropical-modernism-bawa',
    title: 'The Architecture of Tropical Modernism: Geoffrey Bawa’s Island Blueprint',
    category: 'Architecture',
    author: 'Alistair Sterling',
    authorTitle: 'Architectural Historian & Fellow of the Royal Society of Arts',
    readTime: '6 min read',
    publishDate: 'Autumn 2026',
    heroImage: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=80',
    excerpt: 'How a barrister-turned-architect erased the boundary between tropical wilderness and domestic shelter, forever changing modern hospitality design.',
    pullQuote: '“Architecture cannot be totally explained in terms of either space or form; it is about how light falls on clay tile, and how the monsoon breeze enters the room.”',
    content: [
      'In 1948, Geoffrey Bawa bought an abandoned rubber and cinnamon estate on a tranquil promontory jutting into Dedduwa Lake near Bentota. His initial intention was simple: to create an Italianate garden in the tropics. Instead, over fifty years of painstaking manipulation, he created Lunuganga—a sanctuary that would launch the architectural philosophy known worldwide as Tropical Modernism.',
      'Unlike European modernists who sought to dominate their surroundings with sealed concrete boxes and air conditioning, Bawa treated nature as an equal collaborator. Walls dissolved into open colonnades; courtyard water ponds reflected sky and palm canopies; breezes were funnelled across terracotta tiles to create passive cooling long before sustainable architecture became an industry buzzword.',
      'Today, when one steps onto the verandahs of Popular Ceylon’s curated properties—from Lunuganga to the cliffside pavilions of Tangalle—one experiences this timeless dialogue between human refuge and raw tropical earth.'
    ]
  },
  {
    id: 'secrets-of-high-grown-tea',
    title: 'High-Grown Broken Orange Pekoe: Secrets of the Dimbula Mist',
    category: 'Botany & Tea',
    author: 'Priyantha Jayawardena',
    authorTitle: 'Master Tea Taster & Grand Cupper, Ceylon Tea Board',
    readTime: '5 min read',
    publishDate: 'Winter 2026',
    heroImage: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1200&q=80',
    excerpt: 'The delicate chemistry of altitude, morning mist, and artisanal brass rollers that produces the golden liqueur of the Bogawantalawa Valley.',
    pullQuote: '“At 1,500 meters, when the Southwest monsoon gives way to crisp dry winds in February, the tea bush stresses. In that stress, the golden aromatic oils are born.”',
    content: [
      'To understand Ceylon tea is to understand microclimates. Within an island smaller than Scotland, seven distinct agro-climatic zones produce teas so radically different in liquor color, astringency, and bouquet that a blind tasting can pinpoint the very hillside of harvest.',
      'In the high-grown valleys of Dimbula and Bogawantalawa—known colloquially as the Golden Valley—the Camellia sinensis bush grows slowly under low temperatures and dense mist. This slow maturation forces the plant to concentrate polyphenols and essential aromatic terpenes in the tender apical shoot: the legendary two leaves and a bud.',
      'In the historic orthodox tea factories still operating with 1930s Marshall and Walker rollers, withering tables gently dehydrate the leaf under cool highland breezes before rolling fractures the cell walls, unlocking the enzymatic oxidation that yields a liquor glowing with the radiance of melted topaz.'
    ]
  },
  {
    id: 'ghost-leopards-of-yala',
    title: 'Tracking the Apex Monarchs: The Secret Leopards of Yala Block One',
    category: 'Wildlife Chronicles',
    author: 'Dr. Rohan Senanayake',
    authorTitle: 'Senior Feline Biologist & Wilderness Consultant',
    readTime: '7 min read',
    publishDate: 'Spring 2026',
    heroImage: 'https://images.unsplash.com/photo-1561731216-c3a4d99437d5?auto=format&fit=crop&w=1200&q=80',
    excerpt: 'Why Sri Lanka’s leopards behave unlike any other big cat on Earth, and the ethical safari practices protecting their coastal kingdom.',
    pullQuote: '“Without lions or tigers to contest the crown, the Ceylon leopard walks with unhurried royalty down the middle of open sandy tracks.”',
    content: [
      'For over ten millennia since the land bridge across the Palk Strait submerged, Panthera pardus kotiya has evolved in splendid biological isolation. On the African continent, a leopard lives in perpetual vigilance, caching kills in high acacia branches to avoid hyenas and lion prides. In Ceylon, however, the leopard is the unquestioned king of the jungle.',
      'This lack of apex competition has bred an extraordinary feline bold enough to lounge in full view atop massive granite gneiss boulders, soaking up the early morning sun while axis deer herd nervously below.',
      'Our private expeditions partner strictly with experienced conservation wardens who navigate uncrowded peripheral buffer zones, utilizing electric 4x4 vehicles to observe these magnificent predators without disturbing their vital hunting rhythms.'
    ]
  }
];
